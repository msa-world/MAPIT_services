
"use client";

import Navigation from "@/components/sections/navigation";
import Footer from "@/components/sections/footer";

import React, { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2, XCircle, Loader2, MessageSquare, Users, Headphones, ArrowRight, Globe, Shield, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

interface FormData {
  fullName: string;
  email: string;
  company: string;
  phone: string;
  serviceInterest: string;
  projectDescription: string;
}

interface FormErrors {
  fullName?: string;
  email?: string;
  company?: string;
  phone?: string;
  serviceInterest?: string;
  projectDescription?: string;
}

export default function ContactPage() {
  const heroRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const locationsRef = useRef<HTMLDivElement>(null);
  const supportRef = useRef<HTMLDivElement>(null);
  const faqRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    email: '',
    company: '',
    phone: '',
    serviceInterest: '',
    projectDescription: ''
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero section animations
      gsap.fromTo('.hero-title', 
        { opacity: 0, y: 50 },
        { opacity: 1, y: 0, duration: 1, ease: 'power3.out' }
      );

      gsap.fromTo('.hero-subtitle', 
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1, delay: 0.2, ease: 'power3.out' }
      );

      // Form fields stagger animation
      gsap.fromTo('.form-field', 
        { opacity: 0, y: 20 },
        { 
          opacity: 1, 
          y: 0, 
          duration: 0.6, 
          stagger: 0.1, 
          delay: 0.4,
          ease: 'power3.out' 
        }
      );

      // Company info animation
      gsap.fromTo('.company-info', 
        { opacity: 0, x: 50 },
        { opacity: 1, x: 0, duration: 1, delay: 0.6, ease: 'power3.out' }
      );

      // ScrollTriggered animations
      gsap.fromTo('.locations-grid', 
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: locationsRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      gsap.fromTo('.support-card', 
        { opacity: 0, scale: 0.9 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.8,
          stagger: 0.2,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: supportRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      gsap.fromTo('.faq-item', 
        { opacity: 0, x: -30 },
        {
          opacity: 1,
          x: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: faqRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse'
          }
        }
      );

    });

    return () => ctx.revert();
  }, []);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }

    if (!formData.company.trim()) {
      newErrors.company = 'Company name is required';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }

    if (!formData.serviceInterest) {
      newErrors.serviceInterest = 'Please select a service interest';
    }

    if (!formData.projectDescription.trim()) {
      newErrors.projectDescription = 'Project description is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error('Please fill in all required fields');
      return;
    }

    setIsSubmitting(true);

    // Simulate API call
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setIsSubmitted(true);
      toast.success('Message sent successfully! We\'ll get back to you within 24 hours.');
      
      // Reset form after success
      setTimeout(() => {
        setFormData({
          fullName: '',
          email: '',
          company: '',
          phone: '',
          serviceInterest: '',
          projectDescription: ''
        });
        setIsSubmitted(false);
      }, 3000);

    } catch (error) {
      toast.error('Failed to send message. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const offices = [
  
  ];

  const supportOptions = [
    {
      icon: Headphones,
      title: 'Technical Support',
      description: 'Get help with our GIS platforms, data processing, and technical implementation.',
      contact: 'support@gisremotesensing.com',
      hours: '24/7 Priority Support',
      response: 'Within 2 hours'
    },
    {
      icon: Users,
      title: 'Sales & Partnerships',
      description: 'Discuss enterprise solutions, custom projects, and partnership opportunities.',
      contact: 'sales@gisremotesensing.com',
      hours: 'Mon-Fri, 9AM-6PM',
      response: 'Within 24 hours'
    },
    {
      icon: MessageSquare,
      title: 'Consultation Services',
      description: 'Expert guidance on GIS strategy, remote sensing applications, and spatial analysis.',
      contact: 'consulting@gisremotesensing.com',
      hours: 'By Appointment',
      response: 'Within 48 hours'
    }
  ];

  const faqItems = [
    {
      question: 'What GIS services do you provide?',
      answer: 'We offer comprehensive GIS solutions including spatial analysis, remote sensing, cartographic services, database development, and custom application development for various industries.'
    },
    {
      question: 'How long does a typical GIS project take?',
      answer: 'Project timelines vary based on complexity and scope. Simple mapping projects may take 2-4 weeks, while comprehensive GIS implementations can take 3-6 months or longer for enterprise solutions.'
    },
    {
      question: 'Do you work with specific GIS software platforms?',
      answer: 'Yes, we work with all major GIS platforms including Esri ArcGIS, QGIS, PostGIS, MapInfo, and various remote sensing software like ENVI, ERDAS, and Google Earth Engine.'
    },
    {
      question: 'Can you handle large-scale enterprise projects?',
      answer: 'Absolutely. We have extensive experience with enterprise-level GIS implementations, serving Fortune 500 companies, government agencies, and large organizations worldwide.'
    },
    {
      question: 'What industries do you serve?',
      answer: 'We serve diverse industries including urban planning, environmental monitoring, agriculture, utilities, telecommunications, transportation, defense, and natural resource management.'
    }
  ];

  return (
    <>
      <Navigation />
      <div className="min-h-screen bg-black text-white">
        {/* Hero Section */}
        <section ref={heroRef} className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/5" />
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-accent/20 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            {/* Contact Form */}
            <div className="order-2 lg:order-1">
              <div className="hero-title mb-4">
                <h1 className="text-4xl lg:text-5xl font-semibold leading-tight font-sans tracking-tight">
                  Get in <span className="text-primary">Touch</span>
                </h1>
              </div>
              <div className="hero-subtitle mb-10">
                <p className="text-lg lg:text-xl text-muted-foreground max-w-lg font-sans">
                  Ready to transform your spatial data capabilities? Let's discuss your GIS and remote sensing needs.
                </p>
              </div>

              <Card className="backdrop-blur-md bg-surface-dark/80 border-border/50 rounded-xl shadow-lg max-w-xl mx-auto font-sans">
                <CardContent className="p-6 md:p-8">
                  {isSubmitted ? (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="text-center py-8"
                    >
                      <CheckCircle2 className="w-16 h-16 text-success-green mx-auto mb-4" />
                      <h3 className="text-2xl font-medium mb-2">Message Sent!</h3>
                      <p className="text-muted-foreground">
                        Thank you for contacting us. We'll get back to you within 24 hours.
                      </p>
                    </motion.div>
                  ) : (
                    <form ref={formRef} onSubmit={handleSubmit} className="space-y-5 font-sans">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="form-field">
                          <label className="block text-base font-semibold mb-2 tracking-tight">Full Name *</label>
                          <Input
                            value={formData.fullName}
                            onChange={(e) => handleInputChange('fullName', e.target.value)}
                            className={`bg-surface-medium/50 border-border/50 focus:border-primary text-base py-2 ${errors.fullName ? 'border-destructive' : ''}`}
                            placeholder="Enter your full name"
                          />
                          {errors.fullName && (
                            <p className="text-destructive text-xs mt-1 font-medium">{errors.fullName}</p>
                          )}
                        </div>
                        <div className="form-field">
                          <label className="block text-base font-semibold mb-2 tracking-tight">Email Address *</label>
                          <Input
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            className={`bg-surface-medium/50 border-border/50 focus:border-primary text-base py-2 ${errors.email ? 'border-destructive' : ''}`}
                            placeholder="your.email@company.com"
                          />
                          {errors.email && (
                            <p className="text-destructive text-xs mt-1 font-medium">{errors.email}</p>
                          )}
                        </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="form-field">
                          <label className="block text-base font-semibold mb-2 tracking-tight">Company *</label>
                          <Input
                            value={formData.company}
                            onChange={(e) => handleInputChange('company', e.target.value)}
                            className={`bg-surface-medium/50 border-border/50 focus:border-primary text-base py-2 ${errors.company ? 'border-destructive' : ''}`}
                            placeholder="Your company name"
                          />
                          {errors.company && (
                            <p className="text-destructive text-xs mt-1 font-medium">{errors.company}</p>
                          )}
                        </div>
                        <div className="form-field">
                          <label className="block text-base font-semibold mb-2 tracking-tight">Phone Number *</label>
                          <Input
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                            className={`bg-surface-medium/50 border-border/50 focus:border-primary text-base py-2 ${errors.phone ? 'border-destructive' : ''}`}
                            placeholder="+1 (555) 123-4567"
                          />
                          {errors.phone && (
                            <p className="text-destructive text-xs mt-1 font-medium">{errors.phone}</p>
                          )}
                        </div>
                      </div>
                      <div className="form-field">
                        <label className="block text-base font-semibold mb-2 tracking-tight">Service Interest *</label>
                        <Select
                          value={formData.serviceInterest}
                          onValueChange={(value) => handleInputChange('serviceInterest', value)}
                        >
                          <SelectTrigger className={`bg-surface-medium/50 border-border/50 focus:border-primary text-base py-2 ${errors.serviceInterest ? 'border-destructive' : ''}`}>
                            <SelectValue placeholder="Select a service" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="gis-consulting">GIS Consulting</SelectItem>
                            <SelectItem value="remote-sensing">Remote Sensing Services</SelectItem>
                            <SelectItem value="spatial-analysis">Spatial Analysis</SelectItem>
                            <SelectItem value="custom-development">Custom Development</SelectItem>
                            <SelectItem value="data-processing">Data Processing</SelectItem>
                            <SelectItem value="training">Training & Support</SelectItem>
                            <SelectItem value="enterprise">Enterprise Solutions</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        {errors.serviceInterest && (
                          <p className="text-destructive text-xs mt-1 font-medium">{errors.serviceInterest}</p>
                        )}
                      </div>
                      <div className="form-field">
                        <label className="block text-base font-semibold mb-2 tracking-tight">Project Description *</label>
                        <Textarea
                          value={formData.projectDescription}
                          onChange={(e) => handleInputChange('projectDescription', e.target.value)}
                          className={`bg-surface-medium/50 border-border/50 focus:border-primary min-h-28 text-base py-2 ${errors.projectDescription ? 'border-destructive' : ''}`}
                          placeholder="Tell us about your project requirements, timeline, and any specific challenges you're facing..."
                        />
                        {errors.projectDescription && (
                          <p className="text-destructive text-xs mt-1 font-medium">{errors.projectDescription}</p>
                        )}
                      </div>
                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-primary hover:bg-primary/90 text-black font-semibold text-base py-2.5 h-auto transition-all duration-300 hover:scale-[1.02] font-sans"
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                            Sending Message...
                          </>
                        ) : (
                          <>
                            <Send className="w-5 h-5 mr-2" />
                            Send Message
                          </>
                        )}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Company Information */}
            <div className="order-1 lg:order-2 company-info">
              <div className="backdrop-blur-md bg-surface-dark/60 rounded-xl shadow-lg p-6 md:p-8 border border-border/50 max-w-md mx-auto font-sans">
                <h2 className="text-2xl lg:text-3xl font-semibold mb-5 tracking-tight">
                  Contact <span className="text-primary">Information</span>
                </h2>
                <div className="space-y-5">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-primary/20 rounded-lg">
                      <Mail className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1 text-base">Email Us</h3>
                      <p className="text-muted-foreground text-sm">hello@gisremotesensing.com</p>
                      <p className="text-muted-foreground text-sm">support@gisremotesensing.com</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-primary/20 rounded-lg">
                      <Phone className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1 text-base">Call Us</h3>
                      <p className="text-muted-foreground text-sm">+1 (555) 123-4567</p>
                      <p className="text-muted-foreground text-sm">+44 20 7123 4567</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-primary/20 rounded-lg">
                      <Clock className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1 text-base">Business Hours</h3>
                      <p className="text-muted-foreground text-sm">Monday - Friday: 9:00 AM - 6:00 PM</p>
                      <p className="text-muted-foreground text-sm">24/7 Emergency Support Available</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-primary/20 rounded-lg">
                      <Globe className="w-5 h-5 text-primary" />
                    </div>
                  </div>
                </div>
                <div className="mt-7 pt-7 border-t border-border/50">
                  <h3 className="font-semibold mb-3 text-base">Quick Response Promise</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="text-center p-3 bg-surface-medium/30 rounded-lg">
                      <div className="text-xl font-bold text-primary mb-1">2hrs</div>
                      <div className="text-xs text-muted-foreground">Technical Support</div>
                    </div>
                    <div className="text-center p-3 bg-surface-medium/30 rounded-lg">
                      <div className="text-xl font-bold text-primary mb-1">24hrs</div>
                      <div className="text-xs text-muted-foreground">Sales Inquiries</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
  </section>

    

      {/* Support Options */}
      <section ref={supportRef} className="py-20 relative">
        <div className="absolute inset-0">
          <div className="absolute top-1/2 left-1/3 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-light mb-6">
              Support <span className="text-primary">Options</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Choose the right support channel for your needs. Our expert team is ready to assist you with any GIS or remote sensing challenge.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-4">
            {supportOptions.map((option, index) => {
              const IconComponent = option.icon;
              return (
                <Card key={index} className="support-card backdrop-blur-md bg-surface-dark/50 border-border/50 hover:border-primary/50 transition-all duration-300 group hover:scale-105">
                  <CardContent className="p-4 text-center">
                    <div className="p-2 bg-primary/20 rounded-xl inline-block mb-3 group-hover:bg-primary/30 transition-colors">
                      <IconComponent className="w-5 h-5 text-primary" />
                    </div>
                    <h3 className="text-base font-medium mb-2">{option.title}</h3>
                    <p className="text-xs text-muted-foreground mb-3">{option.description}</p>
                    <div className="space-y-2">
                      <div className="flex items-center justify-center gap-1">
                        <Mail className="w-3 h-3 text-primary" />
                        <span className="text-xs font-medium">{option.contact}</span>
                      </div>
                      <div className="flex items-center justify-center gap-1">
                        <Clock className="w-3 h-3 text-primary" />
                        <span className="text-xs text-muted-foreground">{option.hours}</span>
                      </div>
                      <div className="flex items-center justify-center gap-1">
                        <Zap className="w-3 h-3 text-success-green" />
                        <span className="text-xs text-success-green font-medium">Response: {option.response}</span>
                      </div>
                    </div>
                    <Button 
                      className="w-full mt-4 py-1 bg-transparent border border-primary text-primary text-xs hover:bg-primary hover:text-black transition-all duration-300"
                    >
                      Contact Now
                      <ArrowRight className="w-3 h-3 ml-1" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section ref={faqRef} className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-t from-surface-dark/20 to-transparent" />
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-light mb-6">
              Frequently Asked <span className="text-primary">Questions</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Quick answers to common questions about our GIS and remote sensing services.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-6">
              {faqItems.map((item, index) => (
                <Card key={index} className="faq-item backdrop-blur-md bg-surface-dark/50 border-border/50 hover:border-primary/50 transition-all duration-300">
                  <CardContent className="p-8">
                    <h3 className="text-xl font-medium mb-4 text-primary">{item.question}</h3>
                    <p className="text-muted-foreground leading-relaxed">{item.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

  {/* Call to Action */}
  <section ref={ctaRef} className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/20" />
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/30 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-accent/30 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center">
            <h2 className="text-4xl lg:text-6xl font-light mb-8">
              Ready to Start Your <span className="text-primary">GIS Journey</span>?
            </h2>
            <p className="text-xl text-muted-foreground mb-12 max-w-3xl mx-auto">
              Schedule a free consultation with our GIS experts. We'll analyze your requirements and provide a tailored solution proposal within 48 hours.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Button 
                size="lg"
                className="bg-primary hover:bg-primary/90 text-black font-medium px-8 py-4 h-auto transition-all duration-300 hover:scale-105"
              >
                Schedule Free Consultation
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              
              <Button 
                size="lg"
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-black px-8 py-4 h-auto transition-all duration-300 hover:scale-105"
              >
                View Our Portfolio
                <Shield className="w-5 h-5 ml-2" />
              </Button>
            </div>

            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">500+</div>
                <p className="text-muted-foreground">Projects Completed</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">50+</div>
                <p className="text-muted-foreground">Enterprise Clients</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-2">99.9%</div>
                <p className="text-muted-foreground">Uptime Guarantee</p>
              </div>
            </div>
          </div>
        </div>
        </section>
      </div>
      <Footer />
    </>
  );
}