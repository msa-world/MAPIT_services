"use client";

import React, { useState, useEffect } from 'react';
import { Check, X, Star, Zap, Shield, Users, ArrowRight, ChevronDown, ChevronUp, Calculator, Globe, DollarSign, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardHeader, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface PricingPlan {
  id: string;
  name: string;
  monthlyPrice: number;
  annualPrice: number;
  description: string;
  features: string[];
  limitations?: string[];
  mostPopular?: boolean;
  cta: string;
  ctaType: 'primary' | 'secondary' | 'outline';
}

interface AddOn {
  name: string;
  description: string;
  price: number;
  unit: string;
}

interface FAQItem {
  question: string;
  answer: string;
}

const pricingPlans: PricingPlan[] = [
  {
    id: 'starter',
    name: 'Starter',
    monthlyPrice: 49,
    annualPrice: 39,
    description: 'Perfect for small businesses getting started',
    features: [
      'Up to 500 transactions/month',
      'Basic integrations (10+ platforms)',
      'Monthly financial reports',
      'Email support',
      'Mobile app access',
      'Basic AI categorization',
      'Standard security'
    ],
    limitations: [
      'Limited to 1 business entity',
      'No real-time sync',
      'Basic reporting only'
    ],
    cta: 'Start Free Trial',
    ctaType: 'outline'
  },
  {
    id: 'professional',
    name: 'Professional',
    monthlyPrice: 149,
    annualPrice: 119,
    description: 'Best for growing businesses with complex needs',
    features: [
      'Unlimited transactions',
      'All integrations (100+ platforms)',
      'Real-time insights & reporting',
      'Advanced AI-powered categorization',
      'Priority support',
      'Custom workflows',
      'Multi-entity management',
      'Advanced reconciliation',
      'Cash flow forecasting',
      'Tax preparation assistance'
    ],
    mostPopular: true,
    cta: 'Start Free Trial',
    ctaType: 'primary'
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    monthlyPrice: 399,
    annualPrice: 319,
    description: 'Advanced features for established businesses',
    features: [
      'Everything in Professional',
      'Advanced AI features',
      'Dedicated account manager',
      'Custom integrations',
      'SLA guarantees (99.9% uptime)',
      'Advanced security features',
      'White-label options',
      'API access',
      'Custom reporting',
      'Priority implementation',
      'Advanced analytics',
      'Compliance management'
    ],
    cta: 'Start Free Trial',
    ctaType: 'outline'
  },
  {
    id: 'custom',
    name: 'Custom Enterprise',
    monthlyPrice: 0,
    annualPrice: 0,
    description: 'Tailored solutions for large organizations',
    features: [
      'Volume pricing',
      'Custom AI training',
      'White-label solutions',
      'Unlimited API access',
      'Custom reporting & analytics',
      'Dedicated infrastructure',
      '24/7 premium support',
      'Custom integrations',
      'Advanced compliance tools',
      'Multi-region deployment'
    ],
    cta: 'Contact Sales',
    ctaType: 'secondary'
  }
];

const addOns: AddOn[] = [
  {
    name: 'Tax Preparation Pro',
    description: 'Professional tax preparation and filing service',
    price: 299,
    unit: 'per return'
  },
  {
    name: 'Advisory Services',
    description: 'Monthly strategic business advisory sessions',
    price: 150,
    unit: 'per hour'
  },
  {
    name: 'Additional Integrations',
    description: 'Custom platform integrations beyond standard offerings',
    price: 99,
    unit: 'per integration'
  },
  {
    name: 'Priority Implementation',
    description: 'Fast-track setup and onboarding',
    price: 499,
    unit: 'one-time'
  }
];

const faqItems: FAQItem[] = [
  {
    question: 'How does the free trial work?',
    answer: 'All plans include a 14-day free trial with full access to features. No credit card required to start. You can upgrade, downgrade, or cancel anytime during or after the trial period.'
  },
  {
    question: 'Can I switch plans anytime?',
    answer: 'Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately, and billing is prorated automatically.'
  },
  {
    question: 'What payment methods do you accept?',
    answer: 'We accept all major credit cards, ACH transfers, and wire transfers for enterprise customers. All payments are processed securely with bank-level encryption.'
  },
  {
    question: 'Is there a setup fee?',
    answer: 'No setup fees for Starter and Professional plans. Enterprise plans include complimentary setup and onboarding. Priority Implementation is available as an add-on for faster setup.'
  },
  {
    question: 'What if I exceed my transaction limit?',
    answer: 'For Starter plans, additional transactions are billed at $0.10 each. Professional and Enterprise plans include unlimited transactions.'
  },
  {
    question: 'Do you offer refunds?',
    answer: 'We offer a 30-day money-back guarantee for all plans. If you\'re not satisfied, we\'ll provide a full refund of your first month\'s payment.'
  },
  {
    question: 'How secure is my financial data?',
    answer: 'We use bank-level security with 256-bit SSL encryption, SOC 2 Type II compliance, and data centers with 99.9% uptime. Your data is never shared or sold.'
  },
  {
    question: 'Can I integrate with my existing accounting software?',
    answer: 'Yes, we integrate with QuickBooks, Xero, NetSuite, and 100+ other platforms. Our Professional and Enterprise plans include priority integration support.'
  }
];

export default function PricingPage() {
  const [isAnnual, setIsAnnual] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCurrency, setSelectedCurrency] = useState('USD');

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const formatPrice = (price: number) => {
    if (price === 0) return 'Custom';
    return `$${price}`;
  };

  const calculateSavings = (monthly: number, annual: number) => {
    if (monthly === 0 || annual === 0) return 0;
    return Math.round(((monthly * 12 - annual * 12) / (monthly * 12)) * 100);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black">
        {/* Loading Hero Section */}
        <section className="relative py-24 px-4">
          <div className="container mx-auto text-center">
            <Skeleton className="h-16 w-96 mx-auto mb-6 bg-gray-800" />
            <Skeleton className="h-6 w-128 mx-auto mb-8 bg-gray-800" />
            <Skeleton className="h-12 w-64 mx-auto bg-gray-800" />
          </div>
        </section>

        {/* Loading Pricing Cards */}
        <section className="py-16 px-4">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-96 bg-gray-800" />
              ))}
            </div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section */}
      <section className="relative py-24 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-radial from-primary/10 to-transparent opacity-50" />
        <div className="container mx-auto text-center relative z-10">
          <h1 className="text-5xl md:text-6xl font-light mb-6">
            Simple, Transparent{' '}
            <span className="text-primary">Pricing</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Choose the perfect plan for your business. Start with a free trial and scale as you grow.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-16">
            <span className={`text-lg transition-colors ${!isAnnual ? 'text-white' : 'text-muted-foreground'}`}>
              Monthly
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className={`relative w-16 h-8 rounded-full transition-colors duration-300 ${
                isAnnual ? 'bg-primary' : 'bg-gray-600'
              }`}
            >
              <div
                className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform duration-300 ${
                  isAnnual ? 'translate-x-9' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-lg transition-colors ${isAnnual ? 'text-white' : 'text-muted-foreground'}`}>
              Annual
            </span>
            {isAnnual && (
              <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/30">
                Save 20%
              </Badge>
            )}
          </div>
        </div>
      </section>

      {/* Pricing Cards Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {pricingPlans.map((plan, index) => (
              <Card
                key={plan.id}
                className={`relative bg-card border-border hover:border-primary/50 transition-all duration-300 transform hover:scale-105 ${
                  plan.mostPopular ? 'border-primary/50 ring-1 ring-primary/20' : ''
                }`}
                style={{
                  animationDelay: `${index * 100}ms`,
                  animation: 'fadeInUp 0.6s ease-out forwards'
                }}
              >
                {plan.mostPopular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground border-0">
                      <Star className="w-3 h-3 mr-1" />
                      Most Popular
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-8">
                  <h3 className="text-2xl font-semibold mb-2">{plan.name}</h3>
                  <p className="text-muted-foreground mb-6">{plan.description}</p>
                  
                  <div className="space-y-2">
                    <div className="text-4xl font-bold">
                      {formatPrice(isAnnual ? plan.annualPrice : plan.monthlyPrice)}
                      {plan.monthlyPrice > 0 && (
                        <span className="text-lg font-normal text-muted-foreground">
                          /month
                        </span>
                      )}
                    </div>
                    {isAnnual && plan.monthlyPrice > 0 && (
                      <div className="text-sm text-primary">
                        Save {calculateSavings(plan.monthlyPrice, plan.annualPrice)}% annually
                      </div>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {plan.limitations && (
                    <ul className="space-y-2 pt-4 border-t border-border">
                      {plan.limitations.map((limitation, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <X className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                          <span className="text-xs text-muted-foreground">{limitation}</span>
                        </li>
                      ))}
                    </ul>
                  )}

                  <Button
                    className={`w-full ${
                      plan.ctaType === 'primary'
                        ? 'bg-primary hover:bg-primary/90'
                        : plan.ctaType === 'secondary'
                        ? 'bg-secondary hover:bg-secondary/90'
                        : 'border-primary text-primary hover:bg-primary hover:text-primary-foreground'
                    }`}
                    variant={plan.ctaType === 'outline' ? 'outline' : 'default'}
                  >
                    {plan.cta}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Add-ons Section */}
      <section className="py-16 px-4 bg-card/30">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-light mb-6">
              Enhance Your <span className="text-primary">Experience</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Add premium services and features to any plan
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {addOns.map((addon, index) => (
              <Card key={addon.name} className="bg-card border-border hover:border-primary/50 transition-all duration-300">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-2">{addon.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{addon.description}</p>
                  <div className="text-2xl font-bold text-primary">
                    {formatPrice(addon.price)}
                    <span className="text-sm font-normal text-muted-foreground">
                      /{addon.unit}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Table Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-light mb-6">
              Feature <span className="text-primary">Comparison</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Compare all features across our plans
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-4 px-6">Features</th>
                  {pricingPlans.map((plan) => (
                    <th key={plan.id} className="text-center py-4 px-6">
                      <div className="font-semibold">{plan.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {formatPrice(isAnnual ? plan.annualPrice : plan.monthlyPrice)}
                        {plan.monthlyPrice > 0 && '/mo'}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  'Transaction Processing',
                  'Bank Integrations',
                  'Real-time Sync',
                  'AI Categorization',
                  'Advanced Reporting',
                  'Multi-Entity Support',
                  'API Access',
                  'Priority Support',
                  'Custom Integrations',
                  'SLA Guarantees'
                ].map((feature, index) => (
                  <tr key={feature} className="border-b border-border/50">
                    <td className="py-4 px-6 font-medium">{feature}</td>
                    <td className="text-center py-4 px-6">
                      {index < 4 ? (
                        <Check className="w-5 h-5 text-primary mx-auto" />
                      ) : (
                        <X className="w-5 h-5 text-muted-foreground mx-auto" />
                      )}
                    </td>
                    <td className="text-center py-4 px-6">
                      <Check className="w-5 h-5 text-primary mx-auto" />
                    </td>
                    <td className="text-center py-4 px-6">
                      <Check className="w-5 h-5 text-primary mx-auto" />
                    </td>
                    <td className="text-center py-4 px-6">
                      {index < 8 ? (
                        <Check className="w-5 h-5 text-primary mx-auto" />
                      ) : (
                        feature === 'Custom Integrations' ? (
                          <span className="text-sm text-primary">Custom</span>
                        ) : (
                          <Check className="w-5 h-5 text-primary mx-auto" />
                        )
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4 bg-card/30">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-light mb-6">
              Frequently Asked <span className="text-primary">Questions</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Everything you need to know about our pricing and features
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {faqItems.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="bg-card border border-border rounded-lg px-6">
                  <AccordionTrigger className="text-left hover:no-underline py-6">
                    <span className="font-medium">{faq.question}</span>
                  </AccordionTrigger>
                  <AccordionContent className="pb-6 text-muted-foreground">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-5xl font-light mb-6">
            Ready to get <span className="text-primary">started</span>?
          </h2>
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Join thousands of businesses that trust us with their financial operations
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              Start Free Trial
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
              Schedule Demo
              <Calendar className="w-5 h-5 ml-2" />
            </Button>
          </div>

          <div className="mt-12 flex items-center justify-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              <span>Bank-level security</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span>10,000+ businesses</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              <span>99.9% uptime</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}