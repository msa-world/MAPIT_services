import Navigation from "@/components/sections/navigation";
import HeroSection from "@/components/sections/hero";
import { ServicesShowcase } from "@/components/sections/services-showcase";
import GISPerformance from "@/components/sections/ai-performance";
import SatelliteDataAccess from "@/components/sections/global-data-access";
import PreciseSpatialAnalysis from "@/components/sections/accurate-bookkeeping";
import RealtimeMonitoring from "@/components/sections/realtime-insights";
import GeospatialIntelligence from "@/components/sections/ai-personalization";
import GISOperations from "@/components/sections/accounting-operations";
import { PortfolioShowcase } from "@/components/sections/portfolio-showcase";
import CtaSection from "@/components/sections/cta";
import Footer from "@/components/sections/footer";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-black">
      <Navigation />
      
      <main>
        <HeroSection />
        
        <ServicesShowcase />
        
        <GISPerformance />
        
        <div className="space-y-0">
          <SatelliteDataAccess />
          <PreciseSpatialAnalysis />
          <RealtimeMonitoring />
          <GeospatialIntelligence />
        </div>
        
        <GISOperations />
        
        <PortfolioShowcase />
        
        <CtaSection />
      </main>
      
      <Footer />
    </div>
  );
}