"use client";

import { motion } from "framer-motion";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  Calculator, 
  Shield, 
  Globe, 
  FileText, 
  AlertTriangle, 
  FolderOpen,
  Clock,
  CheckCircle,
  ArrowRight,
  BarChart3,
  TrendingUp,
  Users,
  Zap,
  Target,
  BookOpen
} from "lucide-react";

interface PricingPlan {
  name: string;
  price: number;
  yearlyPrice: number;
  description: string;
  features: string[];
  popular?: boolean;
}

interface FAQ {
  question: string;
  answer: string;
}

const pricingPlans: PricingPlan[] = [
  {
    name: "Essentials",
    price: 99,
    yearlyPrice: 89,
    description: "Basic tax compliance for small businesses",
    features: [
      "Automated tax calculations",
      "Basic compliance monitoring",
      "Monthly filings support",
      "Email support",
      "Standard document storage"
    ]
  },
  {
    name: "Professional",
    price: 199,
    yearlyPrice: 179,
    description: "Advanced tax management for growing businesses",
    features: [
      "Everything in Essentials",
      "Multi-jurisdiction support",
      "Real-time compliance alerts",
      "Audit trail management",
      "Priority support",
      "Advanced reporting"
    ],
    popular: true
  },
  {
    name: "Enterprise",
    price: 399,
    yearlyPrice: 359,
    description: "Complete tax solution for large organizations",
    features: [
      "Everything in Professional",
      "Custom integrations",
      "Dedicated account manager",
      "Advanced analytics",
      "White-label options",
      "24/7 phone support"
    ]
  }
];

const faqs: FAQ[] = [
  {
    question: "How does automated tax compliance work?",
    answer: "Our AI continuously monitors your business transactions, automatically categorizes them for tax purposes, calculates liabilities in real-time, and ensures you stay compliant with all applicable tax regulations across multiple jurisdictions."
  },
  {
    question: "Which tax jurisdictions do you support?",
    answer: "We support tax compliance across all 50 US states, major international markets including Canada, UK, EU, and Australia. Our system automatically adapts to local tax requirements based on your business locations and operations."
  },
  {
    question: "What happens if I receive a tax audit?",
    answer: "Our platform maintains comprehensive audit trails for all transactions and decisions. We provide detailed documentation packages and can connect you with tax professionals in our network to support you through the audit process."
  },
  {
    question: "Can I integrate with my existing accounting software?",
    answer: "Yes, we integrate with over 500 accounting platforms including QuickBooks, Xero, NetSuite, and more. Our API allows seamless data synchronization while maintaining compliance oversight."
  },
  {
    question: "How accurate are the automated tax calculations?",
    answer: "Our AI-powered tax engine maintains 99.7% accuracy across all supported jurisdictions. The system is continuously updated with the latest tax regulations and is backed by our compliance guarantee."
  }
];

const benefits = [
  {
    icon: BarChart3,
    title: "Real-time Compliance Monitoring",
    description: "Continuous oversight of your tax obligations with instant alerts for any compliance issues or upcoming deadlines."
  },
  {
    icon: Calculator,
    title: "Automated Tax Calculations",
    description: "AI-powered engine calculates taxes across multiple jurisdictions with 99.7% accuracy, eliminating manual errors."
  },
  {
    icon: Globe,
    title: "Multi-Jurisdiction Support",
    description: "Seamlessly handle tax compliance across all 50 states and international markets with automatic localization."
  },
  {
    icon: Shield,
    title: "Audit Trail Management",
    description: "Comprehensive documentation and audit trails for every transaction, ensuring you're always audit-ready."
  }
];

const features = [
  {
    icon: FileText,
    title: "Automated Tax Filings",
    description: "AI handles all tax filings automatically, ensuring timely submission and accuracy across all jurisdictions."
  },
  {
    icon: TrendingUp,
    title: "Sales Tax Management",
    description: "Real-time sales tax calculations, nexus monitoring, and automated remittance across multiple states."
  },
  {
    icon: Users,
    title: "Payroll Tax Compliance",
    description: "Automated payroll tax calculations, withholdings, and filings for federal, state, and local requirements."
  },
  {
    icon: Globe,
    title: "International Tax Support",
    description: "Cross-border tax compliance including VAT, GST, and transfer pricing for global business operations."
  },
  {
    icon: AlertTriangle,
    title: "Penalty Prevention",
    description: "Proactive monitoring and alerts prevent costly penalties with automated deadline tracking and compliance."
  },
  {
    icon: FolderOpen,
    title: "Document Management",
    description: "Secure storage and organization of all tax documents with intelligent categorization and search."
  }
];

const processSteps = [
  {
    number: "01",
    title: "Connect Your Systems",
    description: "Integrate with your existing accounting, banking, and business systems for comprehensive data access."
  },
  {
    number: "02",
    title: "AI Analysis & Setup",
    description: "Our AI analyzes your business structure, jurisdictions, and requirements to configure optimal compliance."
  },
  {
    number: "03",
    title: "Automated Monitoring",
    description: "Real-time compliance monitoring begins with continuous transaction analysis and obligation tracking."
  },
  {
    number: "04",
    title: "Proactive Management",
    description: "Automated filings, calculations, and alerts ensure you stay compliant without manual intervention."
  }
];

export default function TaxCompliancePage() {
  const [isYearly, setIsYearly] = useState(false);
  const [activeMetric, setActiveMetric] = useState(0);

  const metrics = [
    { label: "Compliance Rate", value: "99.7%", color: "text-accent" },
    { label: "Time Saved", value: "40hrs/mo", color: "text-success-green" },
    { label: "Penalty Prevention", value: "100%", color: "text-primary" },
    { label: "Jurisdictions", value: "50+ States", color: "text-accent" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-accent/10" />
        <div className="container relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Badge className="mb-6 bg-surface-medium text-primary border-primary/20">
                <Zap className="w-3 h-3 mr-1" />
                AI-Powered Tax Compliance
              </Badge>
              <h1 className="text-5xl lg:text-7xl font-light leading-tight mb-6">
                Simplify your{" "}
                <span className="text-accent">Taxes</span>
              </h1>
              <p className="text-xl text-text-secondary mb-8 leading-relaxed">
                Stay compliant year-round with our AI-powered tax engine. Automate calculations, 
                filings, and monitoring across all jurisdictions while eliminating penalties and reducing manual work.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  Start Free Trial
                </Button>
                <Button size="lg" variant="outline" className="border-border hover:bg-surface-medium">
                  Book Demo
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <Card className="bg-surface-dark/50 backdrop-blur-xl border-border/50 p-6">
                <CardContent className="p-0">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-medium">Tax Compliance Dashboard</h3>
                    <Badge className="bg-success-green/10 text-success-green border-success-green/20">
                      All Systems Green
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    {metrics.map((metric, index) => (
                      <motion.div
                        key={metric.label}
                        className={`p-4 rounded-lg border cursor-pointer transition-all duration-300 ${
                          activeMetric === index 
                            ? 'bg-surface-medium border-primary' 
                            : 'bg-surface-dark border-border hover:border-border/70'
                        }`}
                        onClick={() => setActiveMetric(index)}
                        whileHover={{ scale: 1.02 }}
                      >
                        <div className={`text-2xl font-bold ${metric.color} mb-1`}>
                          {metric.value}
                        </div>
                        <div className="text-sm text-text-secondary">{metric.label}</div>
                      </motion.div>
                    ))}
                  </div>

                  <div className="space-y-3">
                    {[
                      { task: "Q4 Sales Tax Filing", status: "Completed", time: "2 min ago" },
                      { task: "Payroll Tax Calculation", status: "Processing", time: "In progress" },
                      { task: "State Registration Check", status: "Scheduled", time: "Tomorrow" }
                    ].map((item, index) => (
                      <motion.div
                        key={item.task}
                        className="flex items-center justify-between p-3 bg-surface-dark rounded-lg"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.5 + index * 0.1 }}
                      >
                        <div className="flex items-center gap-3">
                          <CheckCircle className="w-4 h-4 text-success-green" />
                          <span className="text-sm">{item.task}</span>
                        </div>
                        <div className="text-xs text-text-secondary">{item.time}</div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Key Benefits Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="mb-4 bg-surface-medium text-primary border-primary/20">
              <Target className="w-3 h-3 mr-1" />
              Key Benefits
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-light mb-6">
              Stay compliant with <span className="text-primary">confidence</span>
            </h2>
            <p className="text-xl text-text-secondary max-w-3xl mx-auto">
              Our comprehensive tax compliance solution eliminates the complexity and risk 
              of managing taxes across multiple jurisdictions.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full bg-surface-dark/50 border-border/50 hover:border-primary/30 transition-all duration-300 group">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                      <benefit.icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="text-lg font-medium mb-3">{benefit.title}</h3>
                    <p className="text-text-secondary text-sm leading-relaxed">{benefit.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-surface-dark/30">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-light mb-6">
              Complete <span className="text-accent">tax management</span>
            </h2>
            <p className="text-xl text-text-secondary max-w-3xl mx-auto">
              Comprehensive features covering every aspect of tax compliance and management 
              for businesses of all sizes.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full bg-card/50 backdrop-blur-sm border-border/50 hover:bg-card/70 transition-all duration-300 group">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                      <feature.icon className="w-6 h-6 text-accent" />
                    </div>
                    <h3 className="text-lg font-medium mb-3">{feature.title}</h3>
                    <p className="text-text-secondary text-sm leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Process */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="mb-4 bg-surface-medium text-primary border-primary/20">
              <Clock className="w-3 h-3 mr-1" />
              How It Works
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-light mb-6">
              <span className="text-primary">Automated</span> compliance in 4 steps
            </h2>
            <p className="text-xl text-text-secondary max-w-3xl mx-auto">
              Our intelligent system handles the entire compliance workflow, from setup to ongoing monitoring.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="text-center"
              >
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-xl font-bold text-primary-foreground">{step.number}</span>
                  </div>
                  {index < processSteps.length - 1 && (
                    <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-primary/50 to-transparent transform -translate-y-0.5" />
                  )}
                </div>
                <h3 className="text-lg font-medium mb-3">{step.title}</h3>
                <p className="text-text-secondary text-sm leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-surface-dark/30">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl lg:text-5xl font-light mb-6">
              Choose your <span className="text-primary">plan</span>
            </h2>
            <p className="text-xl text-text-secondary mb-8 max-w-3xl mx-auto">
              Flexible pricing options designed to scale with your business needs and compliance requirements.
            </p>
            
            <div className="flex items-center justify-center gap-4 mb-12">
              <span className={`text-sm ${!isYearly ? 'text-text-primary' : 'text-text-secondary'}`}>
                Monthly
              </span>
              <button
                onClick={() => setIsYearly(!isYearly)}
                className={`relative w-12 h-6 rounded-full transition-colors ${
                  isYearly ? 'bg-primary' : 'bg-surface-medium'
                }`}
              >
                <div
                  className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                    isYearly ? 'transform translate-x-6' : ''
                  }`}
                />
              </button>
              <span className={`text-sm ${isYearly ? 'text-text-primary' : 'text-text-secondary'}`}>
                Yearly
              </span>
              {isYearly && (
                <Badge className="bg-success-green/10 text-success-green border-success-green/20">
                  Save 10%
                </Badge>
              )}
            </div>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {pricingPlans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`h-full relative ${
                  plan.popular 
                    ? 'bg-surface-dark border-primary scale-105' 
                    : 'bg-surface-dark/50 border-border/50'
                }`}>
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <Badge className="bg-primary text-primary-foreground">
                        Most Popular
                      </Badge>
                    </div>
                  )}
                  <CardContent className="p-8">
                    <h3 className="text-xl font-medium mb-2">{plan.name}</h3>
                    <p className="text-text-secondary text-sm mb-6">{plan.description}</p>
                    
                    <div className="mb-6">
                      <div className="flex items-baseline gap-1">
                        <span className="text-4xl font-bold">
                          ${isYearly ? plan.yearlyPrice : plan.price}
                        </span>
                        <span className="text-text-secondary">/month</span>
                      </div>
                      {isYearly && (
                        <p className="text-sm text-success-green mt-1">
                          Save ${(plan.price - plan.yearlyPrice) * 12}/year
                        </p>
                      )}
                    </div>

                    <Button 
                      className={`w-full mb-6 ${
                        plan.popular 
                          ? 'bg-primary hover:bg-primary/90' 
                          : 'bg-surface-medium hover:bg-surface-medium/80'
                      }`}
                    >
                      Get Started
                    </Button>

                    <ul className="space-y-3">
                      {plan.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-3 text-sm">
                          <CheckCircle className="w-4 h-4 text-success-green mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <Badge className="mb-4 bg-surface-medium text-primary border-primary/20">
              <BookOpen className="w-3 h-3 mr-1" />
              FAQ
            </Badge>
            <h2 className="text-4xl lg:text-5xl font-light mb-6">
              Frequently asked <span className="text-accent">questions</span>
            </h2>
            <p className="text-xl text-text-secondary max-w-3xl mx-auto">
              Get answers to common questions about our tax compliance solution and implementation.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem 
                  key={index} 
                  value={`item-${index}`}
                  className="bg-surface-dark/50 border-border/50 rounded-lg px-6"
                >
                  <AccordionTrigger className="text-left hover:no-underline py-6">
                    <span className="text-lg font-medium">{faq.question}</span>
                  </AccordionTrigger>
                  <AccordionContent className="pb-6 text-text-secondary leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-surface-dark via-primary/5 to-accent/5" />
        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-4xl mx-auto"
          >
            <h2 className="text-5xl lg:text-7xl font-light leading-tight mb-8">
              Stay Compliant{" "}
              <span className="text-primary">Effortlessly</span>
            </h2>
            <p className="text-xl text-text-secondary mb-12 max-w-2xl mx-auto leading-relaxed">
              Join thousands of businesses who trust our AI-powered tax compliance solution 
              to handle their complex tax obligations automatically.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8">
                Book Demo
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button size="lg" variant="outline" className="border-border hover:bg-surface-medium px-8">
                Start Free Trial
              </Button>
            </div>
            <p className="text-sm text-text-secondary mt-6">
              No credit card required • 30-day free trial • Setup in minutes
            </p>
          </motion.div>
        </div>
      </section>
    </div>
  );
}