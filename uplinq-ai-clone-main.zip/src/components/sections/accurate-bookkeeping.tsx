"use client";

import React, { useEffect, useRef } from "react";
import Image from "next/image";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function PreciseSpatialAnalysis() {
  const sectionRef = useRef(null);
  const contentRef = useRef(null);
  const dashboardRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Content animation
      gsap.fromTo(contentRef.current, 
        { 
          opacity: 0, 
          x: -50 
        },
        { 
          opacity: 1, 
          x: 0, 
          duration: 1.2, 
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Dashboard animation
      gsap.fromTo(dashboardRef.current, 
        { 
          opacity: 0, 
          x: 50,
          scale: 0.9 
        },
        { 
          opacity: 1, 
          x: 0,
          scale: 1, 
          duration: 1.5, 
          delay: 0.3,
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Animate analysis cards
      gsap.fromTo(dashboardRef.current.querySelectorAll('.analysis-card'), 
        { 
          opacity: 0, 
          y: 20 
        },
        { 
          opacity: 1, 
          y: 0, 
          duration: 0.8, 
          delay: 0.8,
          stagger: 0.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="py-20 lg:py-32 bg-black">
      <div className="container mx-auto px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Left content */}
            <div ref={contentRef} className="space-y-8">
              <div className="space-y-6">
                <h2 className="text-4xl lg:text-6xl font-light leading-tight text-white">
                  <span className="text-primary font-medium">Precise</span>{" "}
                  spatial analysis
                </h2>
                
                <p className="text-lg lg:text-xl text-gray-300 leading-relaxed">
                  Advanced machine learning algorithms automatically classify land cover, 
                  detect changes, and extract meaningful insights from multi-spectral 
                  satellite imagery with sub-meter accuracy.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                  <div>
                    <h3 className="text-white font-medium mb-2">Automated Classification</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      AI-powered algorithms automatically identify and classify land use, 
                      vegetation types, water bodies, and urban features with 99.2% accuracy.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                  <div>
                    <h3 className="text-white font-medium mb-2">Change Detection</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      Monitor temporal changes across landscapes, tracking deforestation, 
                      urban expansion, and environmental shifts over time.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-6 h-6 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                  <div>
                    <h3 className="text-white font-medium mb-2">Multi-Spectral Processing</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">
                      Process data across visible, near-infrared, and thermal bands to 
                      reveal insights invisible to the human eye.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right dashboard */}
            <div ref={dashboardRef} className="relative">
              <div className="relative bg-gradient-to-br from-gray-900/50 to-black/60 backdrop-blur-md rounded-2xl p-6 lg:p-8 border border-white/10">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-white font-medium">Spatial Analysis Dashboard</h3>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-green-400 text-xs">Processing</span>
                  </div>
                </div>

                {/* Analysis results */}
                <div className="space-y-4 mb-6">
                  <div className="analysis-card bg-black/40 backdrop-blur-sm rounded-xl p-4 border border-primary/20">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-white text-sm font-medium">Land Cover Classification</span>
                      <span className="text-primary text-sm">99.2%</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Forest</span>
                        <span className="text-green-400">67.3%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Water</span>
                        <span className="text-blue-400">12.1%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Urban</span>
                        <span className="text-orange-400">8.9%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Agriculture</span>
                        <span className="text-yellow-400">11.7%</span>
                      </div>
                    </div>
                  </div>

                  <div className="analysis-card bg-black/40 backdrop-blur-sm rounded-xl p-4 border border-primary/20">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-white text-sm font-medium">Change Detection</span>
                      <span className="text-primary text-sm">Active</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-red-400 rounded-full"></div>
                        <span className="text-gray-300 text-xs">Deforestation: 0.3% detected</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                        <span className="text-gray-300 text-xs">Water level: +2.1m increase</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
                        <span className="text-gray-300 text-xs">Urban expansion: 1.2% growth</span>
                      </div>
                    </div>
                  </div>

                  <div className="analysis-card bg-black/40 backdrop-blur-sm rounded-xl p-4 border border-primary/20">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-white text-sm font-medium">Spectral Analysis</span>
                      <span className="text-primary text-sm">12 Bands</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {['RGB', 'NIR', 'SWIR', 'TIR', 'PAN', 'COAST'].map((band, index) => (
                        <div key={band} className="text-center">
                          <div className={`w-full h-2 rounded-full mb-1 ${
                            index % 3 === 0 ? 'bg-gradient-to-r from-red-500 to-red-300' :
                            index % 3 === 1 ? 'bg-gradient-to-r from-green-500 to-green-300' :
                            'bg-gradient-to-r from-blue-500 to-blue-300'
                          }`}></div>
                          <span className="text-gray-400 text-xs">{band}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Processing stats */}
                <div className="border-t border-white/10 pt-4">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-lg font-bold text-primary">247</div>
                      <div className="text-xs text-gray-400">Images Processed</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-primary">1.2TB</div>
                      <div className="text-xs text-gray-400">Data Analyzed</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-primary">&lt; 30s</div>
                      <div className="text-xs text-gray-400">Avg. Processing</div>
                    </div>
                  </div>
                </div>

                {/* Glow effect */}
                <div className="absolute -inset-1 bg-gradient-to-br from-primary/20 to-transparent rounded-2xl blur-sm -z-10"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}