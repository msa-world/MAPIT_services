"use client";

import React, { useEffect, useRef } from "react";
import Link from "next/link";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const GeoAnalyticsLogo = () => (
  <div className="relative">
    <h1 className="text-8xl font-bold text-white animate-seagreen-glow">
      <img src="/mapit-logo-red-geometric.png" alt="MAPIT Logo" className="h-25 w-auto" />
    </h1>
  </div>
);


export default function Footer() {
  const footerRef = useRef(null);
  const contentRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Footer content animation
      gsap.fromTo(contentRef.current, 
        { 
          opacity: 0, 
          y: 30 
        },
        { 
          opacity: 1, 
          y: 0, 
          duration: 1, 
          ease: "power3.out",
          scrollTrigger: {
            trigger: footerRef.current,
            start: "top 90%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }, footerRef);

    return () => ctx.revert();
  }, []);

  return (
    <footer ref={footerRef} className="bg-black border-t border-white/10">
      <div className="container mx-auto px-4 py-16">
        <div ref={contentRef} className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-8">
            {/* Logo and description */}
            <div className="lg:col-span-2 space-y-6">
              <Link href="/" aria-label="GeoAnalytics Home">
                <GeoAnalyticsLogo />
              </Link>
              
              <p className="text-gray-400 text-sm leading-relaxed max-w-md">
                Leading the future of geospatial intelligence with advanced satellite data 
                processing, AI-powered analysis, and real-time environmental monitoring solutions.
              </p>
              
              <div className="space-y-2">
                <p className="text-white font-medium text-sm">Global Headquarters</p>
                <p className="text-gray-400 text-sm">
                  123 Geospatial Avenue<br />
                  Innovation District, Tech City 94105<br />
                  United States
                </p>
              </div>
            </div>

            {/* Solutions */}
            <div className="space-y-6">
              <h3 className="text-white font-medium text-base">Solutions</h3>
              <nav className="space-y-3">
                <Link href="/solutions/satellite-analysis" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Satellite Data Analysis
                </Link>
                <Link href="/solutions/geospatial-mapping" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Geospatial Mapping
                </Link>
                <Link href="/solutions/environmental-monitoring" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Environmental Monitoring
                </Link>
                <Link href="/solutions/data-visualization" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Data Visualization
                </Link>
                <Link href="/pricing" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Pricing
                </Link>
              </nav>
            </div>

            {/* Technology */}
            <div className="space-y-6">
              <h3 className="text-white font-medium text-base">Technology</h3>
              <nav className="space-y-3">
                <Link href="/technology/gis-platform" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  GIS Analytics Platform
                </Link>
                <Link href="/technology/security" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Data Security
                </Link>
                <Link href="/technology/integrations" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  API Integrations
                </Link>
                <Link href="/contact" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Request Demo
                </Link>
              </nav>
            </div>

            {/* Company */}
            <div className="space-y-6">
              <h3 className="text-white font-medium text-base">Company</h3>
              <nav className="space-y-3">
                <Link href="/company/mission" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Our Mission
                </Link>
                <Link href="/careers" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Careers
                </Link>
                <Link href="/blog" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Blog
                </Link>
                <Link href="/faqs" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  FAQ
                </Link>
                <Link href="/brand-guidelines" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Brand Resources
                </Link>
                <Link href="/contact" className="block text-gray-400 text-sm hover:text-primary transition-colors">
                  Contact Us
                </Link>
              </nav>
            </div>
          </div>

          {/* Bottom section */}
          <div className="border-t border-white/10 mt-16 pt-8">
            <div className="flex flex-col lg:flex-row justify-between items-center gap-6">
              <div className="flex flex-col lg:flex-row items-center gap-6 text-gray-400 text-sm">
                <p>&copy; 2024 GeoAnalytics. All rights reserved.</p>
                <div className="flex items-center gap-6">
                  <Link href="/privacy" className="hover:text-primary transition-colors">
                    Privacy Policy
                  </Link>
                  <Link href="/terms" className="hover:text-primary transition-colors">
                    Terms of Service
                  </Link>
                  <Link href="/cookies" className="hover:text-primary transition-colors">
                    Cookie Policy
                  </Link>
                </div>
              </div>
              
              <button 
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="flex items-center gap-2 text-gray-400 hover:text-primary transition-colors text-sm group"
              >
                Return to top
                <svg className="w-4 h-4 group-hover:-translate-y-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}