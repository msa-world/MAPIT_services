"use client";

import React, { useEffect, useRef } from "react";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function CtaSection() {
  const sectionRef = useRef(null);
  const contentRef = useRef(null);
  const buttonRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Content animation
      gsap.fromTo(contentRef.current, 
        { 
          opacity: 0, 
          y: 50 
        },
        { 
          opacity: 1, 
          y: 0, 
          duration: 1.2, 
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Button animation
      gsap.fromTo(buttonRef.current, 
        { 
          opacity: 0, 
          scale: 0.9 
        },
        { 
          opacity: 1, 
          scale: 1, 
          duration: 0.8, 
          delay: 0.5,
          ease: "power3.out",
          scrollTrigger: {
            trigger: sectionRef.current,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Button hover animation
      gsap.set(buttonRef.current, {
        onComplete: () => {
          buttonRef.current.addEventListener('mouseenter', () => {
            gsap.to(buttonRef.current, { 
              scale: 1.05, 
              duration: 0.3, 
              ease: "power2.out" 
            });
          });
          
          buttonRef.current.addEventListener('mouseleave', () => {
            gsap.to(buttonRef.current, { 
              scale: 1, 
              duration: 0.3, 
              ease: "power2.out" 
            });
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-32 bg-black overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd-uplinq-com/assets/images/66e9a462b4cc0d430868853c_cta-bg-23.webp"
          alt="Background"
          fill
          className="object-cover opacity-30"
        />
      </div>

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/50 to-black/80 z-10" />
      <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-primary/10 z-10" />

      <div className="container mx-auto px-4 z-20 relative">
        <div className="max-w-5xl mx-auto text-center">
          <div ref={contentRef} className="mb-8">
            <h2 className="text-4xl lg:text-6xl xl:text-7xl font-light leading-tight text-white mb-6">
              Transform your geospatial{" "}
              <span className="text-primary font-medium">intelligence</span>
            </h2>
            
            <p className="text-lg lg:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Unlock the power of satellite data and AI-driven spatial analysis. 
              Join organizations worldwide who trust our platform for mission-critical 
              geospatial intelligence and environmental monitoring.
            </p>
          </div>

          <div ref={buttonRef} className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg text-lg px-8 py-4 h-auto min-w-[200px]">
              <Link href="/contact">Get Started Today</Link>
            </Button>
            
            <Button asChild variant="outline" size="lg" className="border-white/20 text-white hover:bg-white/10 rounded-lg text-lg px-8 py-4 h-auto min-w-[200px]">
              <Link href="/solutions/satellite-analysis">Explore Solutions</Link>
            </Button>
          </div>

          {/* Additional stats */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">50+</div>
              <div className="text-gray-300">Satellite Missions</div>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">99.8%</div>
              <div className="text-gray-300">System Uptime</div>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">24/7</div>
              <div className="text-gray-300">Global Monitoring</div>
            </div>
          </div>
        </div>
      </div>

      {/* Additional background elements */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black to-transparent z-10" />
    </section>
  );
}