"use client";

import { useState, useEffect } from "react";
import { Satellite, Building, Wheat, Trees, Waves, CloudRain } from "lucide-react";

interface ProjectCard {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: JSX.Element;
  imageUrl: string;
}

const projects: ProjectCard[] = [
  {
    id: "satellite-imagery",
    title: "Satellite Imagery Analysis",
    description: "Environmental monitoring and change detection using satellite data to track global environmental changes and patterns.",
    category: "Remote Sensing",
    icon: <Satellite className="w-6 h-6" />,
    imageUrl: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/satellite-imagery-analysis-project-showi-f505c116-20250829125521.jpg"
  },
  {
    id: "urban-planning",
    title: "Urban Planning Solutions",
    description: "Smart city mapping and infrastructure development planning to optimize urban growth and sustainability.",
    category: "Urban Development",
    icon: <Building className="w-6 h-6" />,
    imageUrl: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/smart-city-urban-planning-visualization--abd3bc1c-20250829125530.jpg"
  },
  {
    id: "agricultural-monitoring",
    title: "Agricultural Monitoring",
    description: "Crop health analysis and precision farming solutions to maximize agricultural productivity and efficiency.",
    category: "Agriculture",
    icon: <Wheat className="w-6 h-6" />,
    imageUrl: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/agricultural-monitoring-satellite-analys-65bec571-20250829125634.jpg"
  },
  {
    id: "forest-management",
    title: "Forest Management",
    description: "Deforestation tracking and conservation planning to protect and preserve forest ecosystems worldwide.",
    category: "Conservation",
    icon: <Trees className="w-6 h-6" />,
    imageUrl: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/forest-management-and-deforestation-trac-21173891-20250829125645.jpg"
  },
  {
    id: "coastal-monitoring",
    title: "Coastal Monitoring",
    description: "Sea level rise and coastal erosion analysis to understand and mitigate climate change impacts.",
    category: "Climate Science",
    icon: <Waves className="w-6 h-6" />,
    imageUrl: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/coastal-monitoring-and-sea-level-analysi-c8f2119c-20250829125654.jpg"
  },
  {
    id: "climate-analysis",
    title: "Climate Analysis",
    description: "Weather pattern analysis and climate change modeling to predict and understand global climate trends.",
    category: "Meteorology",
    icon: <CloudRain className="w-6 h-6" />,
    imageUrl: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/climate-analysis-and-weather-pattern-mod-5570732f-20250829125704.jpg"
  }
];

export const PortfolioShowcase = () => {
  const [visibleCards, setVisibleCards] = useState<boolean[]>([]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisibleCards(new Array(projects.length).fill(true));
    }, 200);

    return () => clearTimeout(timer);
  }, []);

  const cardStyles = {
    transform: 'translateY(20px)',
    opacity: 0,
    animation: 'fadeInUp 0.6s ease-out forwards'
  };

  const visibleCardStyles = {
    transform: 'translateY(0)',
    opacity: 1,
    animation: 'none'
  };

  return (
    <>
      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .card-hover {
          transition: all 0.3s ease-in-out;
        }
        
        .card-hover:hover {
          transform: scale(1.02);
          box-shadow: 0 0 30px rgba(0, 212, 170, 0.2);
          border-color: #00D4AA;
        }
        
        .glow-effect {
          position: relative;
          overflow: hidden;
        }
        
        .glow-effect::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(
            90deg,
            transparent,
            rgba(0, 212, 170, 0.1),
            transparent
          );
          transition: left 0.5s;
        }
        
        .glow-effect:hover::before {
          left: 100%;
        }
      `}</style>
      
      <section className="py-24 bg-black">
        <div className="container mx-auto px-4">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-surface-dark border border-border mb-6">
              <span className="text-sm text-primary font-medium">Portfolio Showcase</span>
            </div>
            
            <h2 className="text-5xl md:text-6xl font-light text-white mb-6">
              Our Latest <span className="text-primary">Projects</span>
            </h2>
            
            <p className="text-lg text-text-secondary max-w-2xl mx-auto">
              Explore our cutting-edge solutions spanning environmental monitoring, 
              urban planning, and climate analysis powered by advanced AI technology.
            </p>
          </div>

          {/* Projects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div
                key={project.id}
                className="card-hover glow-effect bg-surface-dark border border-border rounded-xl p-6 backdrop-blur-sm"
                style={{
                  ...(visibleCards[index] ? visibleCardStyles : cardStyles),
                  animationDelay: `${index * 100}ms`
                }}
              >
                {/* Project Image */}
                <div className="aspect-video rounded-lg mb-6 overflow-hidden">
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                  />
                </div>

                {/* Category Badge */}
                <div className="inline-flex items-center px-3 py-1 rounded-full bg-surface-medium border border-border mb-4">
                  <span className="text-xs text-primary font-medium">
                    {project.category}
                  </span>
                </div>

                {/* Project Title */}
                <h3 className="text-xl font-medium text-white mb-3">
                  {project.title}
                </h3>

                {/* Project Description */}
                <p className="text-text-secondary text-sm leading-relaxed">
                  {project.description}
                </p>

                {/* Project Icon */}
                <div className="mt-6 flex items-center justify-between">
                  <div className="flex items-center text-primary">
                    {project.icon}
                    <span className="ml-2 text-sm font-medium">Explore Project</span>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-surface-medium flex items-center justify-center">
                    <svg 
                      className="w-4 h-4 text-primary" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={2} 
                        d="M9 5l7 7-7 7" 
                      />
                    </svg>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};