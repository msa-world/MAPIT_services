"use client";

import React, { useState, useEffect } from 'react';
import { Map, Satellite, Globe, BarChart3 } from 'lucide-react';

interface ServiceCard {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  imageUrl: string;
}

const services: ServiceCard[] = [
  {
    id: 'mapping',
    title: 'Digital Mapping & Cartography',
    description: 'Professional mapping solutions with real-time data integration for comprehensive spatial visualization and analysis.',
    icon: Map,
    imageUrl: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/professional-digital-mapping-workstation-1d4d70f4-20250829125433.jpg'
  },
  {
    id: 'satellite',
    title: 'Satellite Data Processing',
    description: 'Advanced satellite imagery analysis and earth observation services for environmental and agricultural monitoring.',
    icon: Satellite,
    imageUrl: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/advanced-satellite-data-processing-visua-98210c42-20250829125442.jpg'
  },
  {
    id: 'environmental',
    title: 'Environmental Monitoring',
    description: 'Monitor environmental changes using remote sensing technology and predictive analytics for sustainable planning.',
    icon: Globe,
    imageUrl: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/environmental-monitoring-dashboard-displ-fe49f8f4-20250829125459.jpg'
  },
  {
    id: 'analytics',
    title: 'Spatial Analytics',
    description: 'Transform complex geospatial data into actionable business insights with advanced analytics and machine learning.',
    icon: BarChart3,
    imageUrl: 'https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/spatial-analytics-visualization-showing--a707d632-20250829125512.jpg'
  }
];

export const ServicesShowcase = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <section className="py-20 px-4 bg-black relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-radial from-primary/10 via-transparent to-transparent opacity-50" />
      
      <div className="container mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          {/* Chip/Badge */}
          <div 
            className={`inline-flex items-center px-4 py-2 rounded-full bg-surface-dark/50 border border-border backdrop-blur-sm mb-6 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <span className="text-sm font-medium text-text-secondary">Our Services</span>
          </div>

          {/* Main Headline */}
          <h2 
            className={`text-4xl md:text-5xl lg:text-6xl font-light mb-6 transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Transforming data into{' '}
            <span className="text-primary font-medium">intelligence</span>
          </h2>

          {/* Subtitle */}
          <p 
            className={`text-lg text-text-secondary max-w-2xl mx-auto leading-relaxed transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            Comprehensive geospatial solutions powered by cutting-edge technology and 
            decades of expertise in spatial data analysis and visualization.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            const isHovered = hoveredCard === service.id;
            
            return (
              <div
                key={service.id}
                className={`group relative bg-surface-dark/80 backdrop-blur-sm border border-border rounded-xl p-8 transition-all duration-500 cursor-pointer ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                } ${
                  isHovered 
                    ? 'scale-105 border-primary/50 shadow-[0_0_30px_rgba(0,212,170,0.3)]' 
                    : 'hover:scale-102 hover:border-primary/30 hover:shadow-[0_0_20px_rgba(0,212,170,0.2)]'
                }`}
                style={{
                  animationDelay: `${index * 100}ms`,
                  animationFillMode: 'both'
                }}
                onMouseEnter={() => setHoveredCard(service.id)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                {/* Background glow effect */}
                <div 
                  className={`absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent rounded-xl transition-opacity duration-500 ${
                    isHovered ? 'opacity-100' : 'opacity-0'
                  }`} 
                />

                {/* Service Icon */}
                <div className="relative z-10 mb-6">
                  <div 
                    className={`w-16 h-16 rounded-lg bg-surface-medium border border-border flex items-center justify-center transition-all duration-300 ${
                      isHovered ? 'bg-primary/20 border-primary/50' : 'group-hover:bg-primary/10 group-hover:border-primary/30'
                    }`}
                  >
                    <IconComponent 
                      className={`w-8 h-8 transition-colors duration-300 ${
                        isHovered ? 'text-primary' : 'text-text-secondary group-hover:text-primary'
                      }`} 
                    />
                  </div>
                </div>

                {/* Service Content */}
                <div className="relative z-10">
                  <h3 className="text-2xl font-medium text-text-primary mb-4 group-hover:text-primary transition-colors duration-300">
                    {service.title}
                  </h3>
                  <p className="text-text-secondary leading-relaxed mb-6">
                    {service.description}
                  </p>
                </div>

                {/* Service Image */}
                <div className="relative z-10 aspect-video bg-surface-medium rounded-lg overflow-hidden border border-border">
                  <img
                    src={service.imageUrl}
                    alt={service.title}
                    className={`w-full h-full object-cover transition-all duration-500 ${
                      isHovered ? 'scale-110' : 'group-hover:scale-105'
                    }`}
                  />
                  <div 
                    className={`absolute inset-0 bg-gradient-to-t from-black/20 to-transparent transition-opacity duration-300 ${
                      isHovered ? 'opacity-100' : 'opacity-0'
                    }`} 
                  />
                </div>

                {/* Hover overlay */}
                <div 
                  className={`absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent rounded-xl pointer-events-none transition-opacity duration-500 ${
                    isHovered ? 'opacity-100' : 'opacity-0'
                  }`} 
                />
              </div>
            );
          })}
        </div>

        {/* Loading animation keyframes */}
        <style jsx>{`
          @keyframes fadeInUp {
            from {
              opacity: 0;
              transform: translateY(30px);
            }
            to {
              opacity: 1;
              transform: translateY(0);
            }
          }
          
          @keyframes glow {
            0%, 100% {
              box-shadow: 0 0 20px rgba(0, 212, 170, 0.2);
            }
            50% {
              box-shadow: 0 0 30px rgba(0, 212, 170, 0.4);
            }
          }
          
          .animate-fade-in-up {
            animation: fadeInUp 0.8s ease-out forwards;
          }
          
          .animate-glow {
            animation: glow 2s ease-in-out infinite;
          }
        `}</style>
      </div>
    </section>
  );
};