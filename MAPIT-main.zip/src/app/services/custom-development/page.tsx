"use client";

import React, { useState, useEffect } from 'react';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { 
  Code2, 
  Database, 
  Globe, 
  Smartphone, 
  Monitor, 
  Cloud, 
  Layers, 
  Settings, 
  BarChart3, 
  MapPin, 
  Zap, 
  CheckCircle, 
  ArrowRight, 
  Play, 
  Users, 
  Star,
  Terminal,
  GitBranch,
  Server
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Navigation from '@/components/sections/navigation';
import Footer from '@/components/sections/footer';
import Image from "next/image";

const CustomDevelopmentPage = () => {
  const [activeService, setActiveService] = useState(0);
  const [activeProject, setActiveProject] = useState(0);
  const [typedText, setTypedText] = useState('');
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);

  const codeSnippet = `// Web GIS Application Setup
import { Map, View } from 'ol';
import { Tile, Vector } from 'ol/layer';
import { OSM, Vector as VectorSource } from 'ol/source';
import { GeoJSON } from 'ol/format';

const map = new Map({
  target: 'map',
  layers: [
    new Tile({ source: new OSM() }),
    new Vector({
      source: new VectorSource({
        url: '/api/geojson/data',
        format: new GeoJSON()
      })
    })
  ],
  view: new View({
    center: [0, 0],
    zoom: 2
  })
});`;

  useEffect(() => {
    const text = "Custom GIS Development & Web GIS Solutions";
    let index = 0;
    const timer = setInterval(() => {
      if (index < text.length) {
        setTypedText(text.slice(0, index + 1));
        index++;
      } else {
        clearInterval(timer);
      }
    }, 50);
    return () => clearInterval(timer);
  }, []);

  const coreServices = [
    {
      icon: Globe,
      title: "Web GIS Development",
      description: "Custom web-based GIS platforms with interactive mapping, real-time data visualization, and multi-user collaboration capabilities.",
      features: ["Interactive Web Maps", "Real-time Data Streaming", "Multi-user Collaboration", "Responsive Design"]
    },
    {
      icon: Smartphone,
      title: "Mobile GIS Apps",
      description: "Native and cross-platform mobile applications for field data collection, offline mapping, and location-based services.",
      features: ["Offline Mapping", "GPS Integration", "Field Data Collection", "Sync Capabilities"]
    },
    {
      icon: Monitor,
      title: "Desktop Applications",
      description: "Powerful desktop GIS applications with advanced spatial analysis, data processing, and visualization capabilities.",
      features: ["Advanced Analysis", "Data Processing", "Custom Tools", "Enterprise Integration"]
    },
    {
      icon: Code2,
      title: "API Development",
      description: "RESTful APIs and web services for spatial data access, geoprocessing, and integration with existing systems.",
      features: ["RESTful APIs", "GraphQL Support", "Authentication", "Rate Limiting"]
    },
    {
      icon: Database,
      title: "Database Design",
      description: "Spatial database design and optimization for PostGIS, Oracle Spatial, and other spatial database systems.",
      features: ["Spatial Indexing", "Query Optimization", "Data Modeling", "Performance Tuning"]
    },
    {
      icon: BarChart3,
      title: "Spatial Analysis Tools",
      description: "Custom geoprocessing tools and spatial analysis workflows for specific business requirements.",
      features: ["Custom Algorithms", "Automated Workflows", "Statistical Analysis", "Modeling Tools"]
    },
    {
      icon: Layers,
      title: "Dashboard Creation",
      description: "Interactive dashboards and business intelligence tools with spatial data visualization and reporting.",
      features: ["Real-time Dashboards", "Custom Charts", "KPI Monitoring", "Automated Reports"]
    },
    {
      icon: Settings,
      title: "Integration Services",
      description: "System integration services to connect GIS platforms with existing enterprise systems and third-party APIs.",
      features: ["Enterprise Integration", "Third-party APIs", "Data Migration", "System Synchronization"]
    },
    {
      icon: Cloud,
      title: "Cloud Solutions",
      description: "Cloud-based GIS infrastructure setup, deployment, and management on AWS, Azure, and Google Cloud platforms.",
      features: ["Cloud Deployment", "Auto Scaling", "Load Balancing", "Disaster Recovery"]
    },
    {
      icon: Server,
      title: "Maintenance & Support",
      description: "Ongoing maintenance, updates, and technical support for deployed GIS systems and applications.",
      features: ["24/7 Support", "Regular Updates", "Performance Monitoring", "Bug Fixes"]
    }
  ];

  const webGISPlatforms = [
    {
      title: "Interactive Mapping Platforms",
      description: "Build comprehensive web-based mapping platforms with advanced user interaction capabilities.",
      features: ["Pan/Zoom Controls", "Layer Management", "Feature Selection", "Popup Information", "Measurement Tools"]
    },
    {
      title: "Real-time Data Visualization",
      description: "Create dynamic visualizations that update in real-time with streaming spatial data.",
      features: ["Live Data Feeds", "WebSocket Integration", "Animated Markers", "Time-series Animation", "Heat Maps"]
    },
    {
      title: "Multi-user Collaboration",
      description: "Enable collaborative mapping with shared editing, commenting, and real-time synchronization.",
      features: ["Concurrent Editing", "User Permissions", "Comment System", "Version Control", "Conflict Resolution"]
    }
  ];

  const webMappingApps = [
    {
      title: "Custom Map Viewers",
      description: "Tailored map viewing applications with custom styling and functionality.",
      features: ["Custom Basemaps", "Themed Styling", "Print Support", "Export Capabilities", "Bookmark System"]
    },
    {
      title: "Spatial Data Portals",
      description: "Comprehensive portals for spatial data discovery, preview, and download.",
      features: ["Metadata Search", "Data Preview", "Download Center", "User Accounts", "Usage Analytics"]
    },
    {
      title: "Location-based Services",
      description: "Applications providing location-aware services and proximity-based functionality.",
      features: ["Geocoding", "Routing", "Proximity Search", "Location Tracking", "Geofencing"]
    }
  ];

  const webGISTechnologies = [
    { name: "OpenLayers", description: "Modern web mapping library", category: "Frontend" },
    { name: "Leaflet", description: "Lightweight mapping library", category: "Frontend" },
    { name: "ArcGIS JavaScript API", description: "Esri's web mapping API", category: "Frontend" },
    { name: "MapBox GL JS", description: "Vector tile rendering", category: "Frontend" },
    { name: "Cesium", description: "3D globe and map engine", category: "Frontend" },
    { name: "GeoServer", description: "Open source map server", category: "Backend" },
    { name: "PostGIS", description: "Spatial database extension", category: "Database" },
    { name: "GDAL/OGR", description: "Geospatial data abstraction", category: "Processing" }
  ];

  const architectureComponents = [
    {
      title: "Client-Server Architecture",
      description: "Scalable architecture separating presentation and data layers.",
      components: ["Web Client", "Application Server", "Database Server", "Map Server"]
    },
    {
      title: "REST API Layer",
      description: "RESTful services for spatial data access and manipulation.",
      components: ["Endpoint Design", "Data Serialization", "Error Handling", "Documentation"]
    },
    {
      title: "WebSocket Real-time Updates",
      description: "Real-time data streaming for live map updates.",
      components: ["Connection Management", "Message Broadcasting", "Reconnection Logic", "Load Balancing"]
    },
    {
      title: "Cloud Deployment",
      description: "Containerized deployment with auto-scaling capabilities.",
      components: ["Docker Containers", "Kubernetes", "Load Balancers", "CDN Integration"]
    }
  ];

  const portfolioProjects = [
    {
      title: "Environmental Monitoring Web Platform",
      description: "Real-time environmental data monitoring with sensor integration and alert systems.",
      image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/environmental-monitoring-web-gis-platfor-9f39bc8a-20250830043517.jpg",
      technologies: ["OpenLayers", "Node.js", "PostGIS", "WebSocket"],
      features: ["Sensor Data Visualization", "Alert System", "Historical Analysis", "Mobile Responsive"],
      metrics: { users: "500+", dataPoints: "1M+", uptime: "99.9%" }
    },
    {
      title: "Urban Planning WebGIS Portal",
      description: "Comprehensive urban planning tool with zoning analysis and public participation features.",
      image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/urban-planning-web-gis-portal-displaying-d7630898-20250830043526.jpg",
      technologies: ["ArcGIS JS API", "React", "PostgreSQL", "Docker"],
      features: ["Zoning Analysis", "3D Visualization", "Public Comments", "Report Generation"],
      metrics: { users: "1000+", projects: "200+", satisfaction: "95%" }
    },
    {
      title: "Real-time Asset Tracking System",
      description: "Fleet and asset tracking with geofencing, route optimization, and maintenance scheduling.",
      image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/real-time-asset-tracking-system-showing--eb14d2d4-20250830043537.jpg",
      technologies: ["Leaflet", "Express.js", "MongoDB", "Redis"],
      features: ["Live Tracking", "Geofencing", "Route Optimization", "Maintenance Alerts"],
      metrics: { assets: "10K+", routes: "50K+", efficiency: "+25%" }
    },
    {
      title: "Emergency Response Mapping Platform",
      description: "Crisis management platform with incident mapping, resource allocation, and communication tools.",
      image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/emergency-response-mapping-platform-disp-9c5d4dd5-20250830043546.jpg",
      technologies: ["MapBox GL JS", "Python", "PostGIS", "Kafka"],
      features: ["Incident Mapping", "Resource Management", "Communication Hub", "Mobile App"],
      metrics: { incidents: "5K+", responseTime: "-40%", coverage: "100%" }
    },
    {
      title: "Agricultural Management WebApp",
      description: "Precision agriculture platform with field monitoring, crop analysis, and yield prediction.",
      image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/precision-agriculture-web-platform-displ-a0680cd7-20250830043602.jpg",
      technologies: ["Cesium", "Django", "PostgreSQL", "ML Models"],
      features: ["Field Monitoring", "Crop Analysis", "Yield Prediction", "Weather Integration"],
      metrics: { farms: "300+", acres: "100K+", yield: "+15%" }
    },
    {
      title: "Smart City Dashboard",
      description: "Comprehensive city management dashboard with IoT integration and citizen services.",
      image: "https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/smart-city-dashboard-showing-iot-sensor--efab5e79-20250830043554.jpg",
      technologies: ["OpenLayers", "Vue.js", "InfluxDB", "Kubernetes"],
      features: ["IoT Integration", "Service Requests", "Traffic Management", "Energy Monitoring"],
      metrics: { sensors: "50K+", requests: "20K+", efficiency: "+30%" }
    }
  ];

  const developmentProcess = [
    { step: 1, title: "Requirements Analysis", description: "Detailed analysis of business requirements and technical specifications" },
    { step: 2, title: "Architecture Design", description: "System architecture planning and technology stack selection" },
    { step: 3, title: "Database Design", description: "Spatial database schema design and optimization" },
    { step: 4, title: "API Development", description: "Backend services and API development with documentation" },
    { step: 5, title: "Frontend Development", description: "User interface development with responsive design" },
    { step: 6, title: "Integration & Testing", description: "System integration and comprehensive testing procedures" },
    { step: 7, title: "Deployment", description: "Production deployment with CI/CD pipeline setup" },
    { step: 8, title: "Maintenance", description: "Ongoing support, monitoring, and feature enhancements" }
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "GIS Manager",
      company: "City Planning Department",
      content: "The web GIS platform they developed has revolutionized our urban planning process. The real-time collaboration features are game-changing.",
      rating: 5
    },
    {
      name: "Mark Chen",
      role: "Environmental Scientist",
      company: "Green Earth Solutions",
      content: "Their environmental monitoring system processes millions of data points seamlessly. The mobile app for field work is incredibly intuitive.",
      rating: 5
    },
    {
      name: "Lisa Rodriguez",
      role: "Operations Director",
      company: "LogiTrack Corp",
      content: "The asset tracking system improved our operational efficiency by 25%. The real-time dashboards provide exactly the insights we need.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/project-uploads/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd/generated_images/cutting-edge-web-gis-development-workspa-3bd42bde-20250830043508.jpg"
            alt="Web GIS Development Workspace"
            fill
            className="object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-radial from-primary/20 via-transparent to-transparent" />
        </div>
        
        <motion.div 
          className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5"
          style={{ y }}
        />
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-12"
            >
              <Badge variant="outline" className="mb-6 px-4 py-2">
                <Terminal className="w-4 h-4 mr-2" />
                Enterprise GIS Development
              </Badge>
              
              <h1 className="text-6xl lg:text-7xl font-light mb-6">
                <span className="text-primary">{typedText}</span>
                <motion.span
                  animate={{ opacity: [1, 0] }}
                  transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
                  className="text-primary"
                >
                  |
                </motion.span>
              </h1>
              
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
                We build cutting-edge web GIS platforms, mobile applications, and spatial analysis tools 
                that transform how organizations work with geographic data. From interactive web maps to 
                enterprise-scale geospatial solutions.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="bg-primary hover:bg-primary/90">
                  <Play className="w-5 h-5 mr-2" />
                  View Web GIS Demo
                </Button>
                <Button size="lg" variant="outline">
                  <GitBranch className="w-5 h-5 mr-2" />
                  Explore Projects
                </Button>
              </div>
            </motion.div>

            {/* Code Preview */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="bg-card/50 backdrop-blur-sm rounded-2xl p-8 border border-border"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm text-muted-foreground ml-4">WebGIS-Platform.js</span>
              </div>
              <pre className="text-sm text-green-400 font-mono overflow-x-auto">
                <code>{codeSnippet}</code>
              </pre>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Core Development Services */}
      <section className="py-24 bg-card/20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <Badge variant="outline" className="mb-4">
              <Code2 className="w-4 h-4 mr-2" />
              Development Services
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Comprehensive <span className="text-primary">GIS Development</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              From web-based mapping platforms to enterprise desktop applications, 
              we deliver complete geospatial solutions tailored to your needs.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {coreServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="group"
              >
                <Card className="h-full bg-card/50 backdrop-blur-sm border-border hover:border-primary/50 transition-all duration-300">
                  <CardContent className="p-8">
                    <div className="bg-primary/10 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                      <service.icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="text-2xl font-semibold mb-4">{service.title}</h3>
                    <p className="text-muted-foreground mb-6">{service.description}</p>
                    <div className="space-y-2">
                      {service.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Extensive Web GIS Section */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <Badge variant="outline" className="mb-4">
              <Globe className="w-4 h-4 mr-2" />
              Web GIS Expertise
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Advanced <span className="text-primary">Web GIS Solutions</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-4xl mx-auto">
              Specialized in building sophisticated web-based GIS platforms that deliver 
              real-time spatial data visualization, interactive mapping, and collaborative workflows.
            </p>
          </motion.div>

          {/* Web GIS Platform Development */}
          <div className="mb-20">
            <h3 className="text-3xl font-semibold mb-8 text-center">Web GIS Platform Development</h3>
            <div className="grid md:grid-cols-3 gap-8">
              {webGISPlatforms.map((platform, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  className="bg-card/30 rounded-xl p-6 border border-border"
                >
                  <h4 className="text-xl font-semibold mb-4 text-primary">{platform.title}</h4>
                  <p className="text-muted-foreground mb-4">{platform.description}</p>
                  <div className="space-y-2">
                    {platform.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm">
                        <Zap className="w-3 h-3 text-accent flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Web Mapping Applications */}
          <div className="mb-20">
            <h3 className="text-3xl font-semibold mb-8 text-center">Web Mapping Applications</h3>
            <div className="grid md:grid-cols-3 gap-8">
              {webMappingApps.map((app, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                  className="bg-card/30 rounded-xl p-6 border border-border"
                >
                  <h4 className="text-xl font-semibold mb-4 text-primary">{app.title}</h4>
                  <p className="text-muted-foreground mb-4">{app.description}</p>
                  <div className="space-y-2">
                    {app.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-sm">
                        <MapPin className="w-3 h-3 text-accent flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* WebGIS Technologies */}
          <div className="mb-20">
            <h3 className="text-3xl font-semibold mb-8 text-center">WebGIS Technologies</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {webGISTechnologies.map((tech, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  className="bg-gradient-to-br from-card/50 to-card/30 rounded-xl p-6 border border-border text-center group cursor-pointer"
                >
                  <div className="w-12 h-12 bg-primary/10 rounded-lg mx-auto mb-4 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <Code2 className="w-6 h-6 text-primary" />
                  </div>
                  <h4 className="font-semibold mb-2">{tech.name}</h4>
                  <p className="text-sm text-muted-foreground mb-2">{tech.description}</p>
                  <Badge variant="secondary" className="text-xs">{tech.category}</Badge>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Web GIS Architecture */}
          <div>
            <h3 className="text-3xl font-semibold mb-8 text-center">Web GIS Architecture</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {architectureComponents.map((component, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-card/40 rounded-xl p-6 border border-border"
                >
                  <div className="w-12 h-12 bg-accent/10 rounded-lg mb-4 flex items-center justify-center">
                    <Server className="w-6 h-6 text-accent" />
                  </div>
                  <h4 className="text-lg font-semibold mb-3">{component.title}</h4>
                  <p className="text-sm text-muted-foreground mb-4">{component.description}</p>
                  <div className="space-y-1">
                    {component.components.map((comp, idx) => (
                      <div key={idx} className="text-xs text-primary bg-primary/10 rounded px-2 py-1 inline-block mr-1 mb-1">
                        {comp}
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Development Process */}
      <section className="py-24 bg-card/20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <Badge variant="outline" className="mb-4">
              <Settings className="w-4 h-4 mr-2" />
              Development Process
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Our <span className="text-primary">Development Methodology</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              A proven 8-step process that ensures successful delivery of complex GIS projects 
              from conception to deployment and maintenance.
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            {developmentProcess.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`flex items-center gap-8 mb-12 ${index % 2 === 1 ? 'flex-row-reverse' : ''}`}
              >
                <div className="flex-shrink-0">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center shadow-lg">
                    <span className="text-2xl font-bold text-primary-foreground">{step.step}</span>
                  </div>
                </div>
                <div className={`flex-1 ${index % 2 === 1 ? 'text-right' : ''}`}>
                  <h3 className="text-2xl font-semibold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Web GIS Projects Portfolio */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <Badge variant="outline" className="mb-4">
              <Layers className="w-4 h-4 mr-2" />
              Portfolio
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Web GIS <span className="text-primary">Project Showcase</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Explore our extensive portfolio of web GIS applications, from environmental 
              monitoring systems to smart city dashboards.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            {portfolioProjects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -10 }}
                className="group cursor-pointer"
                onClick={() => setActiveProject(index)}
              >
                <Card className="overflow-hidden bg-card/50 backdrop-blur-sm border-border hover:border-primary/50 transition-all duration-300">
                  <div className="aspect-video bg-gradient-to-br from-primary/20 to-accent/20 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <Badge variant="secondary" className="text-xs">
                        Web GIS
                      </Badge>
                    </div>
                    <div className="absolute bottom-4 right-4 flex gap-2">
                      {project.technologies.slice(0, 2).map((tech, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs bg-background/80">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <CardContent className="p-6">
                    <h3 className="text-2xl font-semibold mb-3 group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-muted-foreground mb-4">{project.description}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      {project.features.slice(0, 4).map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          <CheckCircle className="w-3 h-3 text-primary flex-shrink-0" />
                          <span className="truncate">{feature}</span>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex justify-between items-center pt-4 border-t border-border">
                      <div className="flex gap-4 text-sm">
                        {Object.entries(project.metrics).map(([key, value], idx) => (
                          <div key={idx} className="text-center">
                            <div className="font-semibold text-primary">{value}</div>
                            <div className="text-muted-foreground capitalize">{key}</div>
                          </div>
                        ))}
                      </div>
                      <ArrowRight className="w-5 h-5 text-primary group-hover:translate-x-1 transition-transform" />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Client Testimonials */}
      <section className="py-24 bg-card/20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <Badge variant="outline" className="mb-4">
              <Users className="w-4 h-4 mr-2" />
              Client Success
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              What Our <span className="text-primary">Clients Say</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
              >
                <Card className="h-full bg-card/50 backdrop-blur-sm border-border">
                  <CardContent className="p-6">
                    <div className="flex mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-muted-foreground mb-6">"{testimonial.content}"</p>
                    <div>
                      <div className="font-semibold">{testimonial.name}</div>
                      <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                      <div className="text-sm text-primary">{testimonial.company}</div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-24 relative overflow-hidden">
        <motion.div 
          className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10"
          style={{ y }}
        />
        
        <div className="container mx-auto px-6 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h2 className="text-5xl font-light mb-6">
              Ready to Build Your <span className="text-primary">Web GIS Solution</span>?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Let's discuss your geospatial development needs and create a custom solution 
              that transforms how your organization works with spatial data.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                <Globe className="w-5 h-5 mr-2" />
                Start Your Project
              </Button>
              <Button size="lg" variant="outline">
                <Code2 className="w-5 h-5 mr-2" />
                View Technical Docs
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default CustomDevelopmentPage;