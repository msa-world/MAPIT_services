"use client";

import React, { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from '@/components/sections/navigation';
import Footer from '@/components/sections/footer';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Map, 
  Globe, 
  Building2, 
  Zap, 
  Layers, 
  Smartphone, 
  Search, 
  Filter, 
  Play, 
  Award, 
  Users, 
  Target, 
  ArrowRight, 
  CheckCircle, 
  MapPin, 
  Calendar, 
  Star,
  ChevronRight,
  ChevronLeft,
  ExternalLink,
  Download,
  Mail,
  Phone
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Project {
  id: string;
  title: string;
  client: string;
  location: string;
  category: string;
  technology: string[];
  description: string;
  outcomes: string[];
  beforeImage: string;
  afterImage: string;
  featured: boolean;
}

interface Service {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  features: string[];
}

interface Technology {
  name: string;
  category: string;
  description: string;
  icon: React.ReactNode;
}

const mappingServices: Service[] = [
  {
    id: 'topographic',
    title: 'Topographic Mapping',
    description: 'Detailed terrain and elevation mapping for engineering and construction projects.',
    icon: <Map className="w-8 h-8" />,
    features: ['Contour mapping', 'Digital elevation models', 'Terrain analysis', 'Survey-grade accuracy']
  },
  {
    id: 'cadastral',
    title: 'Cadastral Surveys',
    description: 'Property boundary mapping and land ownership documentation services.',
    icon: <Target className="w-8 h-8" />,
    features: ['Property boundaries', 'Legal descriptions', 'Subdivision planning', 'Title support']
  },
  {
    id: 'infrastructure',
    title: 'Infrastructure Mapping',
    description: 'Comprehensive mapping of utilities, roads, and municipal infrastructure.',
    icon: <Building2 className="w-8 h-8" />,
    features: ['Utility mapping', 'Asset management', 'Network analysis', 'Maintenance planning']
  },
  {
    id: '3d-modeling',
    title: '3D Modeling',
    description: 'Advanced 3D visualization and modeling for complex spatial analysis.',
    icon: <Layers className="w-8 h-8" />,
    features: ['Point cloud processing', 'Mesh generation', 'Volume calculations', 'Virtual reality']
  },
  {
    id: 'web-mapping',
    title: 'Web Mapping',
    description: 'Interactive online mapping solutions and geospatial web applications.',
    icon: <Globe className="w-8 h-8" />,
    features: ['Interactive maps', 'Data visualization', 'Custom applications', 'API integration']
  },
  {
    id: 'mobile-gis',
    title: 'Mobile GIS',
    description: 'Field data collection and mobile mapping solutions for real-time operations.',
    icon: <Smartphone className="w-8 h-8" />,
    features: ['Field collection', 'Offline capabilities', 'Real-time sync', 'GPS integration']
  }
];

const featuredProjects: Project[] = [
  {
    id: 'urban-planning',
    title: 'Smart City Infrastructure Mapping',
    client: 'Metropolitan Planning Authority',
    location: 'Downtown District',
    category: 'Urban Planning',
    technology: ['LiDAR', 'Drone Mapping', 'GIS Analysis'],
    description: 'Comprehensive infrastructure mapping for smart city initiative covering 50 square kilometers.',
    outcomes: ['99.8% accuracy achieved', '30% reduction in planning time', 'Integrated 15 data layers'],
    beforeImage: '/api/placeholder/600/400',
    afterImage: '/api/placeholder/600/400',
    featured: true
  },
  {
    id: 'utility-mapping',
    title: 'Underground Utility Network',
    client: 'Regional Utility Company',
    location: 'Industrial Zone',
    category: 'Utilities',
    technology: ['Ground Penetrating Radar', 'GPS Survey', 'CAD Integration'],
    description: 'Detailed mapping of underground utility networks across 25 km of industrial corridors.',
    outcomes: ['Zero service disruptions', 'Complete network visibility', '95% cost savings on excavation'],
    beforeImage: '/api/placeholder/600/400',
    afterImage: '/api/placeholder/600/400',
    featured: true
  },
  {
    id: 'environmental',
    title: 'Coastal Erosion Monitoring',
    client: 'Environmental Protection Agency',
    location: 'Pacific Coastline',
    category: 'Environmental',
    technology: ['Satellite Imagery', 'Photogrammetry', 'Change Detection'],
    description: 'Multi-temporal analysis of coastal changes over 100 km of sensitive shoreline.',
    outcomes: ['10-year trend analysis', 'Early warning system', 'Protected 500 properties'],
    beforeImage: '/api/placeholder/600/400',
    afterImage: '/api/placeholder/600/400',
    featured: true
  },
  {
    id: 'transportation',
    title: 'Highway Corridor Assessment',
    client: 'Department of Transportation',
    location: 'Interstate 95 Corridor',
    category: 'Transportation',
    technology: ['Mobile LiDAR', 'Photogrammetry', 'Traffic Analysis'],
    description: 'Comprehensive mapping and analysis of 200-mile highway corridor for expansion planning.',
    outcomes: ['Traffic flow optimization', 'Safety improvements identified', '$2M in cost savings'],
    beforeImage: '/api/placeholder/600/400',
    afterImage: '/api/placeholder/600/400',
    featured: true
  },
  {
    id: 'mining',
    title: 'Open Pit Mine Monitoring',
    client: 'Mining Corporation',
    location: 'Nevada Mining Site',
    category: 'Mining',
    technology: ['Drone Surveying', 'Volumetric Analysis', 'Slope Monitoring'],
    description: 'Regular monitoring and volumetric analysis of active mining operations.',
    outcomes: ['Real-time safety monitoring', 'Precise volume calculations', 'Operational efficiency +25%'],
    beforeImage: '/api/placeholder/600/400',
    afterImage: '/api/placeholder/600/400',
    featured: false
  },
  {
    id: 'agriculture',
    title: 'Precision Agriculture Mapping',
    client: 'Agricultural Cooperative',
    location: 'Central Valley Farms',
    category: 'Agriculture',
    technology: ['Multispectral Imaging', 'Crop Analysis', 'Yield Mapping'],
    description: 'Precision agriculture mapping across 10,000 acres of farmland.',
    outcomes: ['20% yield increase', 'Optimized irrigation', 'Reduced chemical usage'],
    beforeImage: '/api/placeholder/600/400',
    afterImage: '/api/placeholder/600/400',
    featured: false
  }
];

const technologies: Technology[] = [
  {
    name: 'LiDAR Systems',
    category: 'Data Collection',
    description: 'High-precision laser scanning for detailed terrain mapping',
    icon: <Zap className="w-6 h-6" />
  },
  {
    name: 'Drone Technology',
    category: 'Aerial Mapping',
    description: 'Advanced UAV platforms for aerial surveying and monitoring',
    icon: <Globe className="w-6 h-6" />
  },
  {
    name: 'GIS Software',
    category: 'Analysis',
    description: 'Industry-leading GIS platforms for spatial analysis',
    icon: <Layers className="w-6 h-6" />
  },
  {
    name: 'GPS/GNSS',
    category: 'Positioning',
    description: 'Survey-grade positioning systems for accurate mapping',
    icon: <MapPin className="w-6 h-6" />
  }
];

const stats = [
  { label: 'Projects Completed', value: '2,500+', suffix: '' },
  { label: 'Accuracy Rate', value: '99.8', suffix: '%' },
  { label: 'Coverage Area', value: '50,000', suffix: ' km²' },
  { label: 'Client Satisfaction', value: '98', suffix: '%' }
];

const industries = [
  {
    title: 'Urban Planning',
    description: 'Smart city development and municipal planning solutions',
    benefits: ['Efficient land use', 'Infrastructure optimization', 'Growth planning'],
    icon: <Building2 className="w-8 h-8" />
  },
  {
    title: 'Utilities',
    description: 'Infrastructure mapping and asset management for utilities',
    benefits: ['Network visibility', 'Maintenance planning', 'Service reliability'],
    icon: <Zap className="w-8 h-8" />
  },
  {
    title: 'Environmental',
    description: 'Environmental monitoring and conservation mapping',
    benefits: ['Change detection', 'Impact assessment', 'Conservation planning'],
    icon: <Globe className="w-8 h-8" />
  },
  {
    title: 'Transportation',
    description: 'Highway and transportation infrastructure mapping',
    benefits: ['Safety optimization', 'Traffic analysis', 'Route planning'],
    icon: <Map className="w-8 h-8" />
  }
];

const processSteps = [
  {
    title: 'Data Collection',
    description: 'Advanced surveying and remote sensing data acquisition',
    icon: <Target className="w-6 h-6" />
  },
  {
    title: 'Processing',
    description: 'State-of-the-art data processing and analysis workflows',
    icon: <Layers className="w-6 h-6" />
  },
  {
    title: 'Quality Control',
    description: 'Rigorous validation and accuracy verification procedures',
    icon: <CheckCircle className="w-6 h-6" />
  },
  {
    title: 'Delivery',
    description: 'Professional deliverables and ongoing support services',
    icon: <Award className="w-6 h-6" />
  }
];

export default function MappingSolutions() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [currentServiceIndex, setCurrentServiceIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const heroRef = useRef<HTMLElement>(null);
  const servicesRef = useRef<HTMLElement>(null);
  const projectsRef = useRef<HTMLElement>(null);
  const statsRef = useRef<HTMLElement>(null);
  const counterRefs = useRef<(HTMLSpanElement | null)[]>([]);

  useEffect(() => {
    // Hero animations
    if (heroRef.current) {
      gsap.fromTo(heroRef.current.querySelector('.hero-title'), 
        { opacity: 0, y: 50 },
        { opacity: 1, y: 0, duration: 1, ease: 'power3.out' }
      );

      gsap.fromTo(heroRef.current.querySelector('.hero-subtitle'), 
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1, delay: 0.2, ease: 'power3.out' }
      );

      gsap.fromTo(heroRef.current.querySelectorAll('.hero-stat'), 
        { opacity: 0, y: 20, scale: 0.8 },
        { opacity: 1, y: 0, scale: 1, duration: 0.8, stagger: 0.1, delay: 0.5, ease: 'back.out(1.7)' }
      );
    }

    // Services section animations
    if (servicesRef.current) {
      ScrollTrigger.create({
        trigger: servicesRef.current,
        start: 'top 80%',
        onEnter: () => {
          gsap.fromTo(servicesRef.current!.querySelectorAll('.service-card'), 
            { opacity: 0, y: 30, rotationX: 15 },
            { opacity: 1, y: 0, rotationX: 0, duration: 0.8, stagger: 0.1, ease: 'power3.out' }
          );
        }
      });
    }

    // Projects section animations
    if (projectsRef.current) {
      ScrollTrigger.create({
        trigger: projectsRef.current,
        start: 'top 80%',
        onEnter: () => {
          gsap.fromTo(projectsRef.current!.querySelectorAll('.project-card'), 
            { opacity: 0, scale: 0.9, y: 20 },
            { opacity: 1, scale: 1, y: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out' }
          );
        }
      });
    }

    // Stats counter animation
    if (statsRef.current) {
      ScrollTrigger.create({
        trigger: statsRef.current,
        start: 'top 80%',
        onEnter: () => {
          counterRefs.current.forEach((ref, index) => {
            if (ref) {
              const finalValue = parseInt(stats[index].value.replace(/[^\d]/g, ''));
              gsap.fromTo({ value: 0 }, 
                { value: finalValue, duration: 2, ease: 'power2.out',
                  onUpdate: function() {
                    const currentValue = Math.round(this.targets()[0].value);
                    if (stats[index].value.includes('.')) {
                      ref.textContent = (currentValue / 10).toFixed(1);
                    } else if (stats[index].value.includes('+')) {
                      ref.textContent = currentValue.toLocaleString() + '+';
                    } else {
                      ref.textContent = currentValue.toLocaleString();
                    }
                  }
                }
              );
            }
          });
        }
      });
    }

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  const filteredProjects = selectedCategory === 'all' 
    ? featuredProjects 
    : featuredProjects.filter(project => project.category.toLowerCase() === selectedCategory);

  const categories = ['all', ...Array.from(new Set(featuredProjects.map(p => p.category.toLowerCase())))];

  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,212,170,0.1)_0%,transparent_70%)]" />
        
        {/* Animated background elements */}
        <div className="absolute inset-0">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-primary/30 rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>

        <div className="container mx-auto px-6 text-center relative z-10">
          <h1 className="hero-title text-6xl md:text-8xl font-light mb-6">
            Professional <span className="text-primary">Mapping</span> Solutions
          </h1>
          <p className="hero-subtitle text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto">
            Advanced geospatial mapping services powered by cutting-edge technology and unmatched expertise
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            {stats.map((stat, index) => (
              <div key={stat.label} className="hero-stat">
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                  <CardContent className="p-6 text-center">
                    <div className="text-3xl font-bold text-primary mb-2">
                      <span ref={el => counterRefs.current[index] = el}>0</span>
                      {stat.suffix}
                    </div>
                    <div className="text-sm text-gray-400">{stat.label}</div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>

          <Button size="lg" className="bg-primary hover:bg-primary/90 text-black font-semibold px-8 py-4 rounded-lg">
            Explore Our Work <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Mapping Services Showcase */}
      <section ref={servicesRef} className="py-24 relative">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">
              Comprehensive Solutions
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Mapping <span className="text-primary">Services</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              From topographic surveys to advanced 3D modeling, we deliver precision mapping solutions for every project need
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {mappingServices.map((service, index) => (
              <Card key={service.id} className="service-card bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-500 group">
                <CardHeader>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 bg-primary/20 rounded-lg text-primary group-hover:bg-primary group-hover:text-black transition-colors">
                      {service.icon}
                    </div>
                    <CardTitle className="text-xl">{service.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 mb-6">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-primary" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Projects Gallery */}
      <section ref={projectsRef} className="py-24 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="bg-accent/20 text-accent border-accent/30 mb-4">
              Project Portfolio
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Featured <span className="text-accent">Projects</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Discover our successful mapping projects across diverse industries and applications
            </p>

            {/* Category Filter */}
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => setSelectedCategory(category)}
                  className={selectedCategory === category 
                    ? "bg-accent text-black" 
                    : "border-gray-600 text-gray-300 hover:border-accent hover:text-accent"
                  }
                >
                  {category === 'all' ? 'All Projects' : category.charAt(0).toUpperCase() + category.slice(1)}
                </Button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, index) => (
              <Card 
                key={project.id} 
                className="project-card bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-500 cursor-pointer group"
                onClick={() => setSelectedProject(project)}
              >
                <div className="relative overflow-hidden rounded-t-lg">
                  <img 
                    src={project.afterImage} 
                    alt={project.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
                  <Badge className="absolute top-4 right-4 bg-primary/90 text-black">
                    {project.category}
                  </Badge>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-gray-400 text-sm mb-2">{project.client}</p>
                  <p className="text-gray-300 mb-4 line-clamp-2">{project.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <MapPin className="w-4 h-4" />
                      {project.location}
                    </div>
                    <ExternalLink className="w-4 h-4 text-accent group-hover:text-white transition-colors" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Technology & Equipment */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">
              Advanced Technology
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Cutting-Edge <span className="text-primary">Equipment</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              We utilize the latest surveying equipment and software platforms to ensure the highest accuracy and efficiency
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {technologies.map((tech, index) => (
              <Card key={index} className="bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-300">
                <CardContent className="p-6 text-center">
                  <div className="p-4 bg-primary/20 rounded-lg text-primary mb-4 w-fit mx-auto">
                    {tech.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{tech.name}</h3>
                  <Badge variant="outline" className="mb-3 text-xs">
                    {tech.category}
                  </Badge>
                  <p className="text-gray-300 text-sm">{tech.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Industry Applications */}
      <section className="py-24 bg-gradient-to-b from-gray-900 to-black">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="bg-accent/20 text-accent border-accent/30 mb-4">
              Industry Focus
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Diverse <span className="text-accent">Applications</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Our mapping solutions serve a wide range of industries with specialized expertise and proven results
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {industries.map((industry, index) => (
              <Card key={index} className="bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-500 group">
                <CardContent className="p-8">
                  <div className="flex items-start gap-6">
                    <div className="p-4 bg-accent/20 rounded-lg text-accent group-hover:bg-accent group-hover:text-black transition-colors">
                      {industry.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-semibold mb-3">{industry.title}</h3>
                      <p className="text-gray-300 mb-4">{industry.description}</p>
                      <ul className="space-y-2">
                        {industry.benefits.map((benefit, benefitIndex) => (
                          <li key={benefitIndex} className="flex items-center gap-2 text-sm">
                            <CheckCircle className="w-4 h-4 text-accent" />
                            {benefit}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Workflow */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">
              Our Process
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Proven <span className="text-primary">Workflow</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              From initial data collection to final delivery, our systematic approach ensures quality and precision at every step
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <div key={index} className="relative">
                <Card className="bg-white/5 border-white/10 hover:bg-white/10 transition-all duration-300 text-center">
                  <CardContent className="p-8">
                    <div className="p-4 bg-primary/20 rounded-lg text-primary mb-4 w-fit mx-auto">
                      {step.icon}
                    </div>
                    <div className="absolute -top-2 -left-2 w-8 h-8 bg-primary rounded-full flex items-center justify-center text-black font-bold text-sm">
                      {index + 1}
                    </div>
                    <h3 className="text-lg font-semibold mb-3">{step.title}</h3>
                    <p className="text-gray-300 text-sm">{step.description}</p>
                  </CardContent>
                </Card>
                {index < processSteps.length - 1 && (
                  <ChevronRight className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2 text-primary w-8 h-8" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive Map Features Demo */}
      <section className="py-24 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="bg-accent/20 text-accent border-accent/30 mb-4">
              Interactive Solutions
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Web <span className="text-accent">Mapping</span> Capabilities
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Experience our interactive mapping solutions with advanced visualization and analysis tools
            </p>
          </div>

          <Card className="bg-white/5 border-white/10 max-w-6xl mx-auto">
            <CardContent className="p-8">
              <div className="relative bg-gray-900 rounded-lg h-96 flex items-center justify-center mb-6">
                <div className="text-center">
                  <Globe className="w-16 h-16 text-accent mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">Interactive Map Demo</h3>
                  <p className="text-gray-400 mb-4">Click to explore our web mapping capabilities</p>
                  <Button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="bg-accent hover:bg-accent/90 text-black"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {isPlaying ? 'Pause Demo' : 'Start Demo'}
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <Layers className="w-8 h-8 text-accent mx-auto mb-2" />
                  <div className="text-sm">Layer Control</div>
                </div>
                <div className="text-center">
                  <Search className="w-8 h-8 text-accent mx-auto mb-2" />
                  <div className="text-sm">Advanced Search</div>
                </div>
                <div className="text-center">
                  <Filter className="w-8 h-8 text-accent mx-auto mb-2" />
                  <div className="text-sm">Data Filtering</div>
                </div>
                <div className="text-center">
                  <Target className="w-8 h-8 text-accent mx-auto mb-2" />
                  <div className="text-sm">Measurement Tools</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Client Success Stories */}
      <section ref={statsRef} className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">
              Client Success
            </Badge>
            <h2 className="text-5xl font-light mb-6">
              Trusted by <span className="text-primary">Industry Leaders</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Our clients consistently achieve outstanding results with our mapping solutions
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-8">
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-300 mb-6 italic">
                  "The precision and detail of their mapping services exceeded our expectations. Project completed on time and within budget."
                </p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold">Sarah Johnson</div>
                    <div className="text-sm text-gray-400">Project Manager, MetroPlanning</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-8">
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-300 mb-6 italic">
                  "Outstanding technical expertise and customer service. Their 3D modeling capabilities are truly impressive."
                </p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <div className="font-semibold">Michael Chen</div>
                    <div className="text-sm text-gray-400">Chief Engineer, Infrastructure Corp</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-8">
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-300 mb-6 italic">
                  "Professional team with deep GIS expertise. They delivered comprehensive solutions that transformed our operations."
                </p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-400/20 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-green-400" />
                  </div>
                  <div>
                    <div className="font-semibold">Emily Rodriguez</div>
                    <div className="text-sm text-gray-400">Director, Environmental Solutions</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Client Logos */}
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="w-32 h-16 bg-white/10 rounded-lg flex items-center justify-center">
                <Building2 className="w-8 h-8 text-gray-400" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call-to-Action */}
      <section className="py-24 bg-gradient-to-br from-primary/10 via-black to-accent/10">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-5xl font-light mb-6">
            Ready to Start Your <span className="text-primary">Mapping Project</span>?
          </h2>
          <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
            Contact our team of mapping professionals to discuss your project requirements and get a customized solution proposal
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Contact Form */}
            <Card className="bg-white/5 border-white/10">
              <CardHeader>
                <CardTitle className="text-2xl text-left">Request Project Quote</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <Input placeholder="First Name" className="bg-white/10 border-white/20" />
                  <Input placeholder="Last Name" className="bg-white/10 border-white/20" />
                </div>
                <Input placeholder="Email Address" type="email" className="bg-white/10 border-white/20" />
                <Input placeholder="Company Name" className="bg-white/10 border-white/20" />
                <Input placeholder="Project Location" className="bg-white/10 border-white/20" />
                <Textarea 
                  placeholder="Project Description and Requirements" 
                  className="bg-white/10 border-white/20 min-h-[120px]"
                />
                <Button className="w-full bg-primary hover:bg-primary/90 text-black font-semibold">
                  Submit Request
                </Button>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <div className="space-y-8">
              <Card className="bg-white/5 border-white/10">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <Phone className="w-6 h-6 text-accent" />
                    <div>
                      <div className="font-semibold">Phone</div>
                      <div className="text-gray-300">+1 (555) 123-4567</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 mb-4">
                    <Mail className="w-6 h-6 text-accent" />
                    <div>
                      <div className="font-semibold">Email</div>
                      <div className="text-gray-300">mapping@company.com</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Calendar className="w-6 h-6 text-accent" />
                    <div>
                      <div className="font-semibold">Schedule Consultation</div>
                      <div className="text-gray-300">Book a free 30-minute call</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="space-y-4">
                <Button variant="outline" className="w-full border-accent text-accent hover:bg-accent hover:text-black">
                  <Download className="w-4 h-4 mr-2" />
                  Download Portfolio
                </Button>
                <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-black">
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule Demo
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Project Modal */}
      {selectedProject && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <Card className="bg-gray-900 border-gray-700 max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-2xl">{selectedProject.title}</CardTitle>
              <Button 
                variant="ghost" 
                onClick={() => setSelectedProject(null)}
                className="text-gray-400 hover:text-white"
              >
                ×
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <img 
                  src={selectedProject.beforeImage} 
                  alt="Before"
                  className="w-full h-64 object-cover rounded-lg"
                />
                <img 
                  src={selectedProject.afterImage} 
                  alt="After"
                  className="w-full h-64 object-cover rounded-lg"
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Project Details</h3>
                  <div className="space-y-2 text-sm">
                    <div><strong>Client:</strong> {selectedProject.client}</div>
                    <div><strong>Location:</strong> {selectedProject.location}</div>
                    <div><strong>Category:</strong> {selectedProject.category}</div>
                    <div><strong>Technology:</strong> {selectedProject.technology.join(', ')}</div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Key Outcomes</h3>
                  <ul className="space-y-1">
                    {selectedProject.outcomes.map((outcome, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-primary" />
                        {outcome}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Description</h3>
                <p className="text-gray-300">{selectedProject.description}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Footer />
    </div>
  );
}