"use client";

import React, { useState, useEffect } from "react";
import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { 
  Trophy, 
  Target, 
  TrendingUp, 
  Users, 
  Clock, 
  BarChart3, 
  Building, 
  Calculator, 
  Award, 
  Globe,
  ChevronDown,
  Check,
  ArrowRight,
  DollarSign,
  TrendingDown,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

// Animation variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" }
  }
};

const slideInVariants = {
  hidden: { opacity: 0, x: -30 },
  visible: { 
    opacity: 1, 
    x: 0,
    transition: { duration: 0.6, ease: "easeOut" }
  }
};

// Tax Calculator Component
const TaxCalculatorWidget = () => {
  const [revenue, setRevenue] = useState([500000]);
  const [expenses, setExpenses] = useState([300000]);
  const [currentTaxRate, setCurrentTaxRate] = useState([25]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const taxableIncome = revenue[0] - expenses[0];
  const currentTax = (taxableIncome * currentTaxRate[0]) / 100;
  const optimizedTaxRate = Math.max(15, currentTaxRate[0] - 8);
  const optimizedTax = (taxableIncome * optimizedTaxRate) / 100;
  const savings = currentTax - optimizedTax;
  const savingsPercentage = ((savings / currentTax) * 100).toFixed(0);

  if (isLoading) {
    return (
      <Card className="bg-surface-dark border-border-dark p-6">
        <div className="space-y-4">
          <div className="h-6 bg-surface-medium rounded animate-pulse"></div>
          <div className="h-4 bg-surface-medium rounded w-3/4 animate-pulse"></div>
          <div className="space-y-2">
            <div className="h-3 bg-surface-medium rounded animate-pulse"></div>
            <div className="h-8 bg-surface-medium rounded animate-pulse"></div>
          </div>
          <div className="space-y-2">
            <div className="h-3 bg-surface-medium rounded animate-pulse"></div>
            <div className="h-8 bg-surface-medium rounded animate-pulse"></div>
          </div>
          <div className="h-16 bg-surface-medium rounded animate-pulse"></div>
        </div>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <Card className="bg-surface-dark border-border-dark p-6 backdrop-blur-sm bg-opacity-80">
        <CardHeader className="p-0 mb-6">
          <CardTitle className="text-xl font-semibold text-text-primary">
            Tax Savings Calculator
          </CardTitle>
          <p className="text-text-secondary text-sm">
            See your potential savings with strategic tax planning
          </p>
        </CardHeader>
        
        <div className="space-y-6">
          <div>
            <Label className="text-text-secondary mb-2 block">
              Annual Revenue: ${revenue[0].toLocaleString()}
            </Label>
            <Slider
              value={revenue}
              onValueChange={setRevenue}
              max={2000000}
              min={100000}
              step={50000}
              className="w-full"
            />
          </div>

          <div>
            <Label className="text-text-secondary mb-2 block">
              Annual Expenses: ${expenses[0].toLocaleString()}
            </Label>
            <Slider
              value={expenses}
              onValueChange={setExpenses}
              max={revenue[0] * 0.8}
              min={50000}
              step={25000}
              className="w-full"
            />
          </div>

          <div>
            <Label className="text-text-secondary mb-2 block">
              Current Tax Rate: {currentTaxRate[0]}%
            </Label>
            <Slider
              value={currentTaxRate}
              onValueChange={setCurrentTaxRate}
              max={40}
              min={15}
              step={1}
              className="w-full"
            />
          </div>

          <motion.div 
            className="bg-surface-medium rounded-lg p-4 space-y-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex justify-between">
              <span className="text-text-secondary">Current Tax:</span>
              <span className="text-text-primary font-semibold">${currentTax.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-text-secondary">Optimized Tax:</span>
              <span className="text-primary font-semibold">${optimizedTax.toLocaleString()}</span>
            </div>
            <div className="border-t border-border-dark pt-3">
              <div className="flex justify-between items-center">
                <span className="text-text-primary font-semibold">Annual Savings:</span>
                <div className="text-right">
                  <div className="text-success-green font-bold text-lg">${savings.toLocaleString()}</div>
                  <div className="text-success-green text-sm">{savingsPercentage}% reduction</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </Card>
    </motion.div>
  );
};

// Hero Section
const HeroSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-24 lg:py-32 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,212,170,0.1)_0%,transparent_70%)]"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid lg:grid-cols-2 gap-12 items-center"
        >
          {/* Left Content */}
          <div className="space-y-8">
            <motion.div variants={itemVariants}>
              <Badge variant="secondary" className="bg-surface-medium text-primary border-primary/20 mb-6">
                <Trophy className="w-4 h-4 mr-2" />
                Strategic Tax Planning
              </Badge>
            </motion.div>

            <motion.div variants={itemVariants} className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-light leading-tight">
                Optimize your{" "}
                <span className="text-primary font-medium">Outcomes</span>
              </h1>
              <p className="text-xl text-text-secondary leading-relaxed">
                Maximize your tax savings with intelligent strategic planning. Our expert tax strategists 
                use advanced analytics to identify opportunities and implement customized solutions that 
                reduce your tax burden year-round.
              </p>
            </motion.div>

            <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                Book Strategy Session
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button variant="outline" size="lg" className="border-border-dark hover:bg-surface-medium">
                View Case Studies
              </Button>
            </motion.div>
          </div>

          {/* Right Content - Calculator Widget */}
          <motion.div variants={slideInVariants}>
            <TaxCalculatorWidget />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

// Key Benefits Section
const BenefitsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const benefits = [
    {
      icon: Target,
      title: "Strategic Planning",
      description: "Proactive tax strategies designed around your business goals and financial objectives."
    },
    {
      icon: TrendingUp,
      title: "Maximum Savings",
      description: "Optimize deductions, credits, and timing strategies to minimize your tax liability."
    },
    {
      icon: Users,
      title: "Expert Guidance",
      description: "Dedicated tax strategists with deep expertise in business tax optimization."
    },
    {
      icon: Clock,
      title: "Year-round Support",
      description: "Continuous monitoring and optimization throughout the year, not just at tax time."
    }
  ];

  return (
    <section ref={ref} className="py-24 bg-surface-dark/50">
      <div className="container mx-auto px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {benefits.map((benefit, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="bg-surface-dark border-border-dark h-full hover:border-primary/30 transition-all duration-300 group">
                <CardContent className="p-6 text-center space-y-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto group-hover:bg-primary/20 transition-colors">
                    <benefit.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-text-primary">{benefit.title}</h3>
                  <p className="text-text-secondary leading-relaxed">{benefit.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// Services Section
const ServicesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const services = [
    {
      icon: BarChart3,
      title: "Tax Planning & Forecasting",
      description: "Comprehensive tax planning with scenario modeling and multi-year forecasting."
    },
    {
      icon: Building,
      title: "Entity Structure Optimization",
      description: "Optimize business structure for maximum tax efficiency and operational flexibility."
    },
    {
      icon: Calculator,
      title: "Deduction Maximization",
      description: "Identify and maximize all available deductions and business expense opportunities."
    },
    {
      icon: Award,
      title: "Credit & Incentive Programs",
      description: "Secure tax credits, incentives, and government programs to reduce tax liability."
    },
    {
      icon: Users,
      title: "Succession Planning",
      description: "Strategic planning for business transfers and estate tax minimization."
    },
    {
      icon: Globe,
      title: "International Tax Strategy",
      description: "Navigate complex international tax requirements and optimization opportunities."
    }
  ];

  return (
    <section ref={ref} className="py-24">
      <div className="container mx-auto px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="text-center mb-16"
        >
          <motion.h2 variants={itemVariants} className="text-4xl lg:text-5xl font-light mb-6">
            Comprehensive Tax Services
          </motion.h2>
          <motion.p variants={itemVariants} className="text-xl text-text-secondary max-w-2xl mx-auto">
            From strategic planning to implementation, we provide end-to-end tax optimization services
          </motion.p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {services.map((service, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="bg-surface-dark border-border-dark h-full hover:border-primary/30 transition-all duration-300 group cursor-pointer">
                <CardContent className="p-6 space-y-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <service.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-text-primary">{service.title}</h3>
                  <p className="text-text-secondary leading-relaxed">{service.description}</p>
                  <div className="flex items-center text-primary group-hover:translate-x-1 transition-transform">
                    <span className="text-sm font-medium">Learn more</span>
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// How It Works Section
const HowItWorksSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const steps = [
    {
      number: "01",
      title: "Comprehensive Analysis",
      description: "We analyze your current tax situation, business structure, and financial goals to identify optimization opportunities."
    },
    {
      number: "02", 
      title: "Strategy Development",
      description: "Our experts create a customized tax strategy plan tailored to your specific business needs and objectives."
    },
    {
      number: "03",
      title: "Implementation",
      description: "We execute the tax strategies with precision, handling all documentation and compliance requirements."
    },
    {
      number: "04",
      title: "Ongoing Optimization",
      description: "Continuous monitoring and adjustment of strategies to ensure maximum tax savings year-round."
    }
  ];

  return (
    <section ref={ref} className="py-24 bg-surface-dark/30">
      <div className="container mx-auto px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="text-center mb-16"
        >
          <motion.h2 variants={itemVariants} className="text-4xl lg:text-5xl font-light mb-6">
            How It Works
          </motion.h2>
          <motion.p variants={itemVariants} className="text-xl text-text-secondary max-w-2xl mx-auto">
            Our proven 4-step process ensures maximum tax optimization for your business
          </motion.p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {steps.map((step, index) => (
            <motion.div key={index} variants={itemVariants}>
              <div className="relative">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 bg-primary/10 border-2 border-primary/30 rounded-full flex items-center justify-center mx-auto">
                    <span className="text-2xl font-bold text-primary">{step.number}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-text-primary">{step.title}</h3>
                  <p className="text-text-secondary leading-relaxed">{step.description}</p>
                </div>
                
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-primary/30 to-transparent transform -translate-y-1/2"></div>
                )}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// Case Studies Section
const CaseStudiesSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const caseStudies = [
    {
      company: "Manufacturing Company",
      industry: "Manufacturing",
      metric: "45% tax reduction",
      description: "Implemented strategic entity restructuring and R&D credit optimization, resulting in significant tax savings.",
      savings: "$890K annually"
    },
    {
      company: "Tech Startup",
      industry: "Technology",
      metric: "$2.3M in credits secured",
      description: "Secured R&D tax credits and startup incentives while optimizing equity compensation structures.",
      savings: "$2.3M in credits"
    },
    {
      company: "Real Estate Firm",
      industry: "Real Estate",
      metric: "60% estate tax savings",
      description: "Developed comprehensive succession plan with strategic gifting and trust structures.",
      savings: "$1.2M estate tax saved"
    }
  ];

  return (
    <section ref={ref} className="py-24">
      <div className="container mx-auto px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="text-center mb-16"
        >
          <motion.h2 variants={itemVariants} className="text-4xl lg:text-5xl font-light mb-6">
            Success Stories
          </motion.h2>
          <motion.p variants={itemVariants} className="text-xl text-text-secondary max-w-2xl mx-auto">
            Real results from businesses that transformed their tax strategy
          </motion.p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-3 gap-8"
        >
          {caseStudies.map((study, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className="bg-surface-dark border-border-dark h-full hover:border-primary/30 transition-all duration-300 group">
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary" className="bg-surface-medium text-text-secondary">
                      {study.industry}
                    </Badge>
                    <TrendingDown className="w-5 h-5 text-success-green" />
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-xl font-semibold text-text-primary">{study.company}</h3>
                    <div className="text-2xl font-bold text-success-green">{study.metric}</div>
                  </div>
                  
                  <p className="text-text-secondary leading-relaxed">{study.description}</p>
                  
                  <div className="pt-4 border-t border-border-dark">
                    <div className="flex items-center justify-between">
                      <span className="text-text-secondary text-sm">Annual Impact:</span>
                      <span className="text-primary font-semibold">{study.savings}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// Pricing Section
const PricingSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isYearly, setIsYearly] = useState(false);

  const plans = [
    {
      name: "Essential Strategy",
      monthlyPrice: 299,
      yearlyPrice: 269,
      description: "Perfect for small businesses getting started with tax optimization",
      features: [
        "Annual tax planning session",
        "Quarterly strategy reviews",
        "Basic deduction optimization",
        "Email support",
        "Tax calendar and reminders"
      ]
    },
    {
      name: "Advanced Planning",
      monthlyPrice: 599,
      yearlyPrice: 539,
      description: "Comprehensive tax strategy for growing businesses",
      features: [
        "Bi-annual planning sessions",
        "Monthly strategy reviews",
        "Advanced deduction strategies",
        "Entity structure analysis",
        "Priority phone support",
        "Custom reporting dashboard"
      ],
      popular: true
    },
    {
      name: "Enterprise Solutions",
      monthlyPrice: 1199,
      yearlyPrice: 1079,
      description: "Full-service tax optimization for complex businesses",
      features: [
        "Unlimited planning sessions",
        "Weekly strategy reviews",
        "Multi-entity optimization",
        "International tax planning",
        "Dedicated tax strategist",
        "White-glove implementation"
      ]
    }
  ];

  return (
    <section ref={ref} className="py-24 bg-surface-dark/50">
      <div className="container mx-auto px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="text-center mb-16"
        >
          <motion.h2 variants={itemVariants} className="text-4xl lg:text-5xl font-light mb-6">
            Choose Your Plan
          </motion.h2>
          <motion.p variants={itemVariants} className="text-xl text-text-secondary max-w-2xl mx-auto mb-8">
            Select the tax strategy plan that fits your business needs
          </motion.p>
          
          <motion.div variants={itemVariants} className="flex items-center justify-center gap-4">
            <span className={`text-sm ${!isYearly ? 'text-text-primary' : 'text-text-secondary'}`}>Monthly</span>
            <button
              onClick={() => setIsYearly(!isYearly)}
              className={`relative w-12 h-6 rounded-full transition-colors ${isYearly ? 'bg-primary' : 'bg-surface-medium'}`}
            >
              <div className={`absolute w-4 h-4 bg-white rounded-full top-1 transition-transform ${isYearly ? 'translate-x-7' : 'translate-x-1'}`}></div>
            </button>
            <span className={`text-sm ${isYearly ? 'text-text-primary' : 'text-text-secondary'}`}>
              Yearly <span className="text-success-green font-medium">(Save 10%)</span>
            </span>
          </motion.div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="grid md:grid-cols-3 gap-8"
        >
          {plans.map((plan, index) => (
            <motion.div key={index} variants={itemVariants}>
              <Card className={`bg-surface-dark border-border-dark h-full relative ${plan.popular ? 'border-primary/50 ring-1 ring-primary/20' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground">Most Popular</Badge>
                  </div>
                )}
                
                <CardContent className="p-6 space-y-6">
                  <div className="text-center space-y-2">
                    <h3 className="text-xl font-semibold text-text-primary">{plan.name}</h3>
                    <div className="space-y-1">
                      <div className="text-3xl font-bold text-text-primary">
                        ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                        <span className="text-lg font-normal text-text-secondary">/month</span>
                      </div>
                      {isYearly && (
                        <div className="text-sm text-success-green">
                          Save ${(plan.monthlyPrice - plan.yearlyPrice) * 12} annually
                        </div>
                      )}
                    </div>
                    <p className="text-text-secondary text-sm">{plan.description}</p>
                  </div>

                  <ul className="space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start gap-3">
                        <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <span className="text-text-secondary text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className={`w-full ${plan.popular ? 'bg-primary hover:bg-primary/90' : 'bg-surface-medium hover:bg-surface-medium/80'}`}
                    size="lg"
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// FAQ Section
const FAQSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const faqs = [
    {
      question: "How much can I save with strategic tax planning?",
      answer: "Tax savings vary by business, but our clients typically see 15-40% reductions in their tax liability. The exact amount depends on your current situation, business structure, and the strategies we implement."
    },
    {
      question: "When should I start tax planning for the year?",
      answer: "Tax planning should be year-round, not just at tax time. The best time to implement strategies is early in the tax year, giving us maximum flexibility to optimize your tax position."
    },
    {
      question: "Do you work with businesses of all sizes?",
      answer: "Yes, we work with businesses from startups to large enterprises. Our strategies are customized based on your business size, industry, and specific tax challenges."
    },
    {
      question: "What's included in a tax strategy session?",
      answer: "Our strategy sessions include a comprehensive review of your current tax situation, identification of optimization opportunities, and development of a customized tax plan with implementation timeline."
    },
    {
      question: "How do you ensure compliance while optimizing taxes?",
      answer: "All our strategies are fully compliant with tax laws and regulations. We stay updated on the latest tax code changes and work with your existing tax preparers to ensure proper implementation."
    }
  ];

  return (
    <section ref={ref} className="py-24">
      <div className="container mx-auto px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="max-w-3xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-light mb-6">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-text-secondary">
              Get answers to common questions about our tax strategy services
            </p>
          </motion.div>

          <motion.div variants={itemVariants}>
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem 
                  key={index} 
                  value={`item-${index}`}
                  className="bg-surface-dark border-border-dark rounded-lg px-6"
                >
                  <AccordionTrigger className="text-left text-text-primary hover:text-primary">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-text-secondary leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

// Final CTA Section
const FinalCTASection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-24 bg-gradient-to-b from-surface-dark/30 to-background relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,212,170,0.1)_0%,transparent_70%)]"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-accent/5 to-transparent"></div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="text-center space-y-8"
        >
          <motion.h2 variants={itemVariants} className="text-4xl lg:text-6xl font-light">
            Maximize Your{" "}
            <span className="text-accent font-medium">Tax Savings</span>
          </motion.h2>
          
          <motion.p variants={itemVariants} className="text-xl text-text-secondary max-w-3xl mx-auto leading-relaxed">
            Don't leave money on the table. Our strategic tax planning experts will identify opportunities 
            to reduce your tax burden and improve your bottom line. Start optimizing your tax strategy today.
          </motion.p>

          <motion.div variants={itemVariants} className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule Consultation
            </Button>
            <Button variant="outline" size="lg" className="border-border-dark hover:bg-surface-medium">
              <DollarSign className="w-4 h-4 mr-2" />
              Download Guide
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

// Main Tax Strategy Page Component
export default function TaxStrategyPage() {
  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
      <BenefitsSection />
      <ServicesSection />
      <HowItWorksSection />
      <CaseStudiesSection />
      <PricingSection />
      <FAQSection />
      <FinalCTASection />
    </div>
  );
}