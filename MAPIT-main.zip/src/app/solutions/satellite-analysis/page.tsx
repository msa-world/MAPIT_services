"use client";

import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/sections/navigation';
import Footer from '@/components/sections/footer';
import Link from 'next/link';
import { 
  Satellite, 
  Map, 
  TrendingUp, 
  Clock, 
  Eye, 
  BarChart3,
  Layers,
  Globe,
  TreePine,
  Building,
  Shield,
  ArrowRight,
  CheckCircle,
  Database,
  Download,
  Zap
} from 'lucide-react';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

export default function SatelliteDataAnalysisPage() {
  const heroRef = useRef<HTMLDivElement>(null);
  const capabilitiesRef = useRef<HTMLDivElement>(null);
  const specsRef = useRef<HTMLDivElement>(null);
  const useCasesRef = useRef<HTMLDivElement>(null);
  const workflowRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero animations
      if (heroRef.current) {
        gsap.fromTo(heroRef.current.querySelector('.hero-title'), 
          { opacity: 0, y: 50 },
          { opacity: 1, y: 0, duration: 1, ease: 'power2.out' }
        );
        
        gsap.fromTo(heroRef.current.querySelector('.hero-subtitle'), 
          { opacity: 0, y: 30 },
          { opacity: 1, y: 0, duration: 1, delay: 0.3, ease: 'power2.out' }
        );

        gsap.fromTo(heroRef.current.querySelector('.hero-cta'), 
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, duration: 0.8, delay: 0.6, ease: 'power2.out' }
        );
      }

      // Capabilities staggered animation
      if (capabilitiesRef.current) {
        gsap.fromTo(capabilitiesRef.current.querySelectorAll('.capability-card'),
          { opacity: 0, y: 30, scale: 0.95 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.6,
            stagger: 0.1,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: capabilitiesRef.current,
              start: 'top 80%',
            }
          }
        );
      }

      // Section fade-ins
      const sections = [specsRef, useCasesRef, workflowRef, ctaRef];
      sections.forEach((ref) => {
        if (ref.current) {
          gsap.fromTo(ref.current,
            { opacity: 0, y: 50 },
            {
              opacity: 1,
              y: 0,
              duration: 0.8,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: ref.current,
                start: 'top 80%',
              }
            }
          );
        }
      });

    });

    return () => ctx.revert();
  }, []);

  const capabilities = [
    {
      icon: <Layers className="w-8 h-8" />,
      title: "Multi-spectral Analysis",
      description: "Advanced processing of multi-spectral and hyperspectral satellite imagery for detailed surface analysis."
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Change Detection",
      description: "Temporal analysis to identify and quantify changes in land use, vegetation, and urban development."
    },
    {
      icon: <Map className="w-8 h-8" />,
      title: "Land Cover Classification",
      description: "Automated classification of land cover types using machine learning algorithms and spectral signatures."
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: "Time Series Analysis",
      description: "Long-term monitoring and trend analysis using historical satellite data archives."
    },
    {
      icon: <Eye className="w-8 h-8" />,
      title: "Object Detection",
      description: "AI-powered identification and mapping of specific objects and infrastructure from high-resolution imagery."
    },
    {
      icon: <BarChart3 className="w-8 h-8" />,
      title: "Spectral Indices",
      description: "Calculation of vegetation, water, and urban indices for environmental and agricultural monitoring."
    }
  ];

  const satellites = [
    { name: "Landsat 8/9", resolution: "30m", revisit: "16 days" },
    { name: "Sentinel-2", resolution: "10m", revisit: "5 days" },
    { name: "MODIS", resolution: "250m", revisit: "1-2 days" },
    { name: "WorldView-3", resolution: "0.31m", revisit: "< 1 day" },
    { name: "PlanetScope", resolution: "3m", revisit: "Daily" },
    { name: "SPOT-7", resolution: "1.5m", revisit: "26 days" }
  ];

  const useCases = [
    {
      icon: <TreePine className="w-12 h-12 text-primary" />,
      title: "Agriculture Monitoring",
      description: "Crop health assessment, yield prediction, and precision farming through vegetation indices and growth analysis.",
      benefits: ["95% accuracy in crop classification", "Early disease detection", "Optimized irrigation planning"]
    },
    {
      icon: <Building className="w-12 h-12 text-accent" />,
      title: "Urban Planning",
      description: "City growth tracking, infrastructure monitoring, and sustainable development planning using high-resolution imagery.",
      benefits: ["Real-time urban expansion tracking", "Infrastructure asset management", "Heat island analysis"]
    },
    {
      icon: <Shield className="w-12 h-12 text-success-green" />,
      title: "Environmental Assessment",
      description: "Forest monitoring, water quality analysis, and climate change impact assessment through multi-temporal analysis.",
      benefits: ["Deforestation alerts", "Water body monitoring", "Carbon stock estimation"]
    }
  ];

  const workflowSteps = [
    {
      step: "01",
      title: "Data Acquisition",
      description: "Access and download satellite imagery from multiple platforms and sensors based on your requirements."
    },
    {
      step: "02", 
      title: "Pre-processing",
      description: "Atmospheric correction, geometric correction, and radiometric calibration of raw satellite data."
    },
    {
      step: "03",
      title: "Analysis & Processing",
      description: "Apply advanced algorithms for classification, change detection, and feature extraction."
    },
    {
      step: "04",
      title: "Validation & QA",
      description: "Quality assurance through ground-truth validation and accuracy assessment procedures."
    },
    {
      step: "05",
      title: "Delivery & Insights",
      description: "Generate actionable insights, reports, and deliverables in your preferred format."
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />
      
      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-radial from-primary/20 via-transparent to-transparent opacity-30" />
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 50% 50%, rgba(255,255,255,0.02) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }} />
        
        <div className="container mx-auto px-6 text-center relative z-10">
          <div className="hero-title">
            <h1 className="text-5xl md:text-7xl font-light leading-tight mb-6">
              Advanced <span className="text-primary">Satellite Data</span> Analysis
            </h1>
          </div>
          <div className="hero-subtitle">
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-4xl mx-auto leading-relaxed">
              Unlock the power of multi-spectral imagery with our cutting-edge analysis platform. 
              From precision agriculture to urban planning, transform satellite data into actionable insights.
            </p>
          </div>
          <div className="hero-cta">
            <Link href="/contact">
              <Button className="bg-primary hover:bg-primary/90 text-black font-medium px-8 py-4 text-lg rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/25">
                Start Your Analysis
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent" />
      </section>

      {/* Capabilities Overview */}
      <section ref={capabilitiesRef} className="py-24 relative">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-light mb-6">
              Comprehensive <span className="text-primary">Analysis Capabilities</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Advanced geospatial intelligence through state-of-the-art satellite data processing and machine learning algorithms.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {capabilities.map((capability, index) => (
              <div 
                key={index}
                className="capability-card group bg-surface-dark/50 backdrop-blur-sm border border-border rounded-xl p-8 hover:bg-surface-dark/80 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/10"
              >
                <div className="text-primary mb-4 group-hover:scale-110 transition-transform duration-300">
                  {capability.icon}
                </div>
                <h3 className="text-xl font-medium mb-4 text-white">{capability.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{capability.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section ref={specsRef} className="py-24 bg-surface-dark/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-light mb-6">
              <span className="text-primary">Technical</span> Specifications
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Supporting a wide range of satellite platforms and sensors for comprehensive Earth observation analysis.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-medium mb-8 text-white">Supported Satellite Platforms</h3>
              <div className="space-y-4">
                {satellites.map((satellite, index) => (
                  <div key={index} className="bg-surface-medium/50 backdrop-blur-sm rounded-lg p-4 border border-border hover:bg-surface-medium/80 transition-colors duration-300">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium text-white">{satellite.name}</h4>
                      <div className="flex space-x-4 text-sm text-muted-foreground">
                        <span>{satellite.resolution}</span>
                        <span>{satellite.revisit}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-8">
              <div className="bg-surface-dark/50 backdrop-blur-sm rounded-xl p-8 border border-border">
                <h3 className="text-xl font-medium mb-6 text-white flex items-center">
                  <Database className="w-6 h-6 text-primary mr-3" />
                  Processing Capabilities
                </h3>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-success-green mr-3" />Up to 99.5% classification accuracy</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-success-green mr-3" />Sub-pixel change detection</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-success-green mr-3" />Real-time processing capabilities</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-success-green mr-3" />Multi-temporal analysis</li>
                </ul>
              </div>

              <div className="bg-surface-dark/50 backdrop-blur-sm rounded-xl p-8 border border-border">
                <h3 className="text-xl font-medium mb-6 text-white flex items-center">
                  <Download className="w-6 h-6 text-accent mr-3" />
                  Output Formats
                </h3>
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-success-green mr-3" />GeoTIFF, NetCDF, HDF formats</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-success-green mr-3" />Shapefile and GeoJSON vectors</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-success-green mr-3" />Interactive web maps and dashboards</li>
                  <li className="flex items-center"><CheckCircle className="w-4 h-4 text-success-green mr-3" />Custom reports and analytics</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section ref={useCasesRef} className="py-24">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-light mb-6">
              Real-world <span className="text-primary">Applications</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Transform satellite data into actionable insights across diverse industries and use cases.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {useCases.map((useCase, index) => (
              <div key={index} className="bg-surface-dark/50 backdrop-blur-sm border border-border rounded-xl p-8 hover:bg-surface-dark/80 transition-all duration-300 hover:scale-105">
                <div className="mb-6">{useCase.icon}</div>
                <h3 className="text-2xl font-medium mb-4 text-white">{useCase.title}</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">{useCase.description}</p>
                <ul className="space-y-2">
                  {useCase.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-center text-sm text-muted-foreground">
                      <CheckCircle className="w-4 h-4 text-success-green mr-2 flex-shrink-0" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Workflow */}
      <section ref={workflowRef} className="py-24 bg-surface-dark/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-light mb-6">
              Our <span className="text-primary">Analysis Workflow</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              A systematic approach from raw satellite data to actionable insights, ensuring quality and accuracy at every step.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            {workflowSteps.map((step, index) => (
              <div key={index} className="flex items-start mb-12 last:mb-0">
                <div className="flex-shrink-0 w-16 h-16 bg-primary/20 border-2 border-primary rounded-full flex items-center justify-center mr-6">
                  <span className="text-primary font-bold text-lg">{step.step}</span>
                </div>
                <div className="flex-1 pt-2">
                  <h3 className="text-xl font-medium mb-3 text-white">{step.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
                {index < workflowSteps.length - 1 && (
                  <div className="absolute left-8 mt-20 w-0.5 h-12 bg-gradient-to-b from-primary to-transparent"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section ref={ctaRef} className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-accent/5 to-transparent" />
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 50% 50%, rgba(0,212,170,0.03) 1px, transparent 1px)`,
          backgroundSize: '60px 60px'
        }} />
        
        <div className="container mx-auto px-6 text-center relative z-10">
          <h2 className="text-4xl md:text-6xl font-light mb-6">
            Ready to unlock <span className="text-primary">satellite insights</span>?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Transform your satellite data into actionable intelligence with our advanced analysis platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/contact">
              <Button className="bg-primary hover:bg-primary/90 text-black font-medium px-8 py-4 text-lg rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/25">
                <Zap className="mr-2 w-5 h-5" />
                Start Analysis
              </Button>
            </Link>
            <Link href="/demo">
              <Button variant="outline" className="border-primary text-primary hover:bg-primary/10 font-medium px-8 py-4 text-lg rounded-lg transition-all duration-300 hover:scale-105">
                Request Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}