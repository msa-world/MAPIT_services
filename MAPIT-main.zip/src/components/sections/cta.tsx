"use client";

import React, { useEffect, useRef } from "react";

export default function CtaSection() {
  const sectionRef = useRef(null);
  const contentRef = useRef(null);
  const buttonRef = useRef(null);

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-32 bg-black overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/object/public/test-clones/6a3aa022-36e0-487b-8b3a-6b6d8524b7cd-uplinq-com/assets/images/66e9a462b4cc0d430868853c_cta-bg-23.webp"
          alt="Background"
          className="object-cover opacity-30 w-full h-full"
        />
      </div>

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/50 to-black/80 z-10" />
      <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-primary/10 z-10" />

      <div className="container mx-auto px-4 z-20 relative">
        <div className="max-w-5xl mx-auto text-center">
          <div ref={contentRef} className="mb-8">
            <h3 className="text-4xl lg:text-6xl xl:text-7xl font-light leading-tight text-white mb-6">
              Transform your GIS <span className="text-primary font-medium">workflows</span>
            </h3>
            
            <p className="text-lg lg:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Unlock the power of accurate cadastral data and efficient digitization. Join organizations worldwide who trust our platform for modern land administration and web GIS access.
            </p>
          </div>

          <div ref={buttonRef} className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            {/* Using a standard a tag instead of the Button/Link components which require additional libraries */}
            <a href="/contact" className="inline-flex items-center justify-center bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg text-lg px-8 py-4 h-auto min-w-[200px] font-medium">
              Get Started Today
            </a>
            
            <a href="/solutions/gis-solutions" className="inline-flex items-center justify-center border border-white/20 text-white hover:bg-white/10 rounded-lg text-lg px-8 py-4 h-auto min-w-[200px] font-medium">
              Explore Solutions
            </a>
          </div>

          {/* Additional stats */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">50+</div>
              <div className="text-gray-300">Cadastral Projects</div>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">99.8%</div>
              <div className="text-gray-300">Data Accuracy</div>
            </div>
            <div className="text-center">
              <div className="text-3xl lg:text-4xl font-bold text-primary mb-2">24/7</div>
              <div className="text-gray-300">Web GIS Access</div>
            </div>
          </div>
        </div>
      </div>

      {/* Additional background elements */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black to-transparent z-10" />
    </section>
  );
}
