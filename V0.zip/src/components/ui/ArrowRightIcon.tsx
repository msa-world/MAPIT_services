// Icon for Explore More button
import { ArrowRight } from "lucide-react";

export default ArrowRight;
